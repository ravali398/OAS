package com.May10.pack4;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.May10.pack4.dao.IPaymentDao;
import com.May10.pack4.exception.InvalidPaymentException;
import com.May10.pack4.exception.NoExistenceOfPaymentDetails;
import com.May10.pack4.exception.PaymentCreationException;
import com.May10.pack4.model.Payment;
import com.May10.pack4.repository.IPaymentRepository;

//The SpringBootTest annotation mainly used on the class where tests are performed on that particular class
@SpringBootTest
class Demo2ApplicationTests {
//@Autowired
@MockBean
private IPaymentRepository paymentRepos;
//@Autowired
@MockBean
IPaymentDao service;
//test is used to signal that annotated method is a test method and the methods corresponding to test must not be private or static or it should contain no return value for the test methods
	@Test
	public void testSave() throws PaymentCreationException
	{
	Payment payment=new Payment();
	/*payment.setApplicationId(666);
	payment.setPaymentAmount(20000);
	payment.setPaymentDescription("Books Fee");
	payment.setEmailId("vihan39@gmail.com");
	payment.setPaymentDate(Date.valueOf(LocalDate.now()));
	payment.setPaymentId(600);
	payment.setPaymentStatus("passed");
		Payment t=null;*/
		
		 	//t= service.addPayment(payment);
		 	when(paymentRepos.save(payment)).thenReturn(payment);
		
	//assert not null indicates that it asserts that actual is not null	
	//assertNotNull(t);
		}
	/*@Test
	public void testSave1()
	{
	Payment payment1=new Payment();
	/*payment1.setApplicationId(555);
	payment1.setPaymentAmount(25000);
	payment1.setEmailId("vihaan@gmail.com");
	payment1.setPaymentDescription("Damage Fee");
	payment1.setPaymentDate(Date.valueOf(LocalDate.now()));
	payment1.setPaymentId(650);
	payment1.setPaymentStatus("passed");
		Payment t=null;*/
		/*try {
		 	//t= service.addPayment(payment1);
		 	when(paymentRepos.save(payment1)).thenReturn(payment1);
		} catch (PaymentCreationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	//assertNotNull(t);
		}*/


	@Test
	public  void viewAllPaymentDetails()
	{
	 	List t= service.viewAllPaymentDetails();
	 	//assertThat creates a new instance of List assert
	 	//assertThat(t).size().isGreaterThan(0);
	 	when(paymentRepos.findAll()).thenReturn(t);
	}
	@Test
	public void testForUpdate()
	{
		Payment p=new Payment();
		/*Payment t=paymentRepos.findById(650).get();
		t.setPaymentAmount(5500);
		paymentRepos.save(t);*/
        //assertNotEquals indicate assert that expected and actual are not equal
		//assertNotEquals("adfd", paymentRepos.findById(650).get().getPaymentAmount());	
		when(paymentRepos.updatePayment(p.getPaymentAmount(),p.getEmailId(),p.getPaymentDescription(), p.getPaymentId())).thenReturn(1);
	
	}

	@Test
	public void testForDelete() throws InvalidPaymentException
	{
		//int status=0;
		//status =service.deletePaymentById(345);
			when(service.deletePaymentById(328)).thenReturn(1);
			//assertEquals indicate assert that expected and actual are  equal
			//assertEquals(1, status);
		 /*catch (InvalidPaymentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
	}
}
	