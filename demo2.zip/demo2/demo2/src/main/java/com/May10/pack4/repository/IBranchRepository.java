package com.May10.pack4.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.May10.pack4.model.Branch;
@Repository
public interface IBranchRepository extends JpaRepository<Branch, Integer>{
   	@Query(value="select * from branch_table",nativeQuery=true)
	public List<Branch> viewAllBranchDetails();
   	
	@Query(value="select * from branch_table where branch_name=?1",nativeQuery=true)
	public List<Branch> getBranchDetailsByName(String branchName);
	
	@Query(value="select * from branch_table where branch_id=?1",nativeQuery=true)
	public int getBranchid(int branchid);
	
	@Transactional
	@Modifying
	@Query(value="delete from Branch b where b.branchId=?1")
	public int deleteBranchById(int branchId);
	@Transactional
	@Modifying
	@Query(value="delete from Branch b where b.branchName=?1")
	public int deleteBranchByName(String  branchName);
	@Transactional
	@Modifying
	@Query(value="update branch_table set branch_description=?1 where branch_id=?2",nativeQuery=true)
	public int UpdateBranch(String branchDescription,int branchId );
}
