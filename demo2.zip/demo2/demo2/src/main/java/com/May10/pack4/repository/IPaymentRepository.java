package com.May10.pack4.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.May10.pack4.model.Payment;
//repository annotation indicates that class is repository
//repository is a mechanism for encapsulation storage,retrieval, and search behavior which emulates a collection of objects".   
@Repository
public interface IPaymentRepository extends JpaRepository<Payment, Integer> {
//transactional annotation describes a transaction attribute on an individual method or on a class. 
//modifying indicates a query method should be considered as modifying query as that changes the way it needs to be executed. 
//Query Annotation to declare finder queries directly on repository methods. 
	@Transactional
	@Modifying
	@Query(value="delete from Payment p where p.paymentId=?1")
	public int deletePaymentById(int paymentId);
	@Query(value="select * from payment_table where payment_status=?1",nativeQuery=true)
	public List<Payment> getPaymentDetailsByStatus(String status);
	@Query(value="select * from payment_table where email_id=?1",nativeQuery=true)
	public List<Payment> getPaymentDetailsByEmailId(String emailId);
	@Transactional
	@Modifying
	@Query(value="update Payment p set p.paymentAmount=?1,p.emailId=?2,p.paymentDescription=?3 where p.paymentId=?4")
	public int updatePayment(double paymentAmount,String emailId,String paymentDescription,int paymentId );
	@Query(value="select * from payment_table where application_id=?1",nativeQuery=true)
	public Payment getPaymentDetailsByApplicationId(int applicationId);
}
