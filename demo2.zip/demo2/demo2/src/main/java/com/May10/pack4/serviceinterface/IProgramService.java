package com.May10.pack4.serviceinterface;
import java.util.List;
import com.	May10.pack4.model.Program;

public interface IProgramService {
	public Program addProgram(Program program);
	public List<Program> viewAllProgramDetails();
	public List<Program> getProgramDetailsByName(String programName);
	public List<Program> getProgramDetailsByEligibility(String eligibility);
	public int deleteProgramById(int programid);
	public int deleteProgamByName(String programName);
	public Program getProgramById(int programid);
	public int updateProgramStatus(Program program);
	

}
