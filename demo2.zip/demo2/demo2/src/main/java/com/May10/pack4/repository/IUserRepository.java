package com.May10.pack4.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.May10.pack4.model.Course;
import com.May10.pack4.model.User;

public interface IUserRepository extends JpaRepository<User,String> {
@Transactional
@Modifying
@Query(value="delete from User u where u.userId=?1")
public int deleteUserDetailsById(String Id);

@Query(value="select * from user1_table where user_id=?1",nativeQuery=true)
public User getUserDetailsById(String Id);
@Transactional
@Modifying
@Query(value="update User u set u.firstName=?1 where u.userId=?2")
public int UpdateUser(String firstName,String Id);
@Query(value="select * from user1_table where email=?1",nativeQuery=true)
public User getUserDetailsByemail(String email);

}