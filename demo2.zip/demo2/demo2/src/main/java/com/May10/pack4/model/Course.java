package com.May10.pack4.model;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Range;

import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;


import java.util.*;
//@Entity annotation is used to the class.
@Entity
//@Table annotation specifies the name of the database table.
@Table(name="Course_table")
public class Course {
	//@Id annotation specifies the primary key of an entity.
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	//The annotated has to be in the appropriate range. Apply on numeric values or string representation of the numeric value.
	
private int courseId;
	//not be null
	@NotBlank(message="Course name cannot be blank")	
private String courseName;
	
private String eligiblity;
	//Specifies a single-valued association to another entity class that has many-to-one multiplicity.
@ManyToOne(cascade=CascadeType.ALL)
private College college;
    //Specifies a many-valued association with one-to-many multiplicity.
@OneToMany(fetch=FetchType.LAZY,cascade=CascadeType.REMOVE)
private List<Branch> branches;

//Getters and Setters
public int getCourseId() {
	return courseId;
}
public void setCourseId(int courseId) {
	this.courseId = courseId;
}
public String getCourseName() {
	return courseName;
}
public void setCourseName(String courseName) {
	this.courseName = courseName;
}
public String getEligiblity() {
	return eligiblity;
}
public void setEligiblity(String eligiblity) {
	this.eligiblity = eligiblity;
}

public College getCollege() {
	return college;
}
public void setCollege(College college) {
	this.college = college;
}
public List<Branch> getBranches() {
	return branches;
}
public void setBranches(List<Branch> branches) {
	this.branches = branches;
}

}
