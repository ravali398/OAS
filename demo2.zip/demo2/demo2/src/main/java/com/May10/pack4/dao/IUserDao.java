package com.May10.pack4.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.May10.pack4.exception.CreateUserException;
import com.May10.pack4.exception.InvalidPaymentException;
import com.May10.pack4.exception.InvalidUserException;
import com.May10.pack4.model.Login;
import com.May10.pack4.model.User;
import com.May10.pack4.repository.ILoginRepository;
import com.May10.pack4.repository.IUserRepository;
import com.May10.pack4.serviceinterface.IUserService;
@Service
public class IUserDao implements IUserService{
@Autowired
private IUserRepository userrepository;
@Autowired
private ILoginRepository loginrepository;
@Override
public User addUserDetails(User user)throws CreateUserException {
	// TODO Auto-generated method stub
	if(userrepository.existsById(user.getUserId()))
		throw new CreateUserException("user already exists");
	else
		return userrepository.save(user);
	
}
@Override
public Login addLoginDetails(Login login) {
	// TODO Auto-generated method stub
	return loginrepository.save(login);
}
@Override
public List<User> getAllUserDetails() {
	// TODO Auto-generated method stub
	return userrepository.findAll();
}
@Override
public List<Login> getAllLoginDetails() {
	// TODO Auto-generated method stub
	return loginrepository.findAll();
}
@Override
public User getUserDetailsById(String Id) {
	// TODO Auto-generated method stub
	return  userrepository.getUserDetailsById(Id);
}
@Override
public Login getLoginDetailsById(String userid) {
	// TODO Auto-generated method stub
	return loginrepository.getloginDetailsById(userid);
}
@Override
public User deleteUserDetailsById(String Id) {
	// TODO Auto-generated method stub
	int k=userrepository.deleteUserDetailsById(Id);
if(k==1) {
	return userrepository.getUserDetailsById(Id);
}else {
	return null;
}
}
@Override
public Login deleteLoginDetailsById(String userid) {
	// TODO Auto-generated method stub
	int k=loginrepository.deleteLoginDetailsById(userid);
	if(k==1) {
		return loginrepository.getloginDetailsById(userid);
	}else {
		return null;
	}
}
@Override
public Login changePassword(Login login) {
	// TODO Auto-generated method stub
	String k=login.getLoginId();
	String w=login.getPassword();
	int e=loginrepository.ChangePassword(w,k);
	if(e==1) {
		return login;
	}else {
		return null;
	}
}
@Override
public Login resetPassword(Login login) {
	// TODO Auto-generated method stub
	String k=login.getLoginId();
	String w=login.getPassword();
	int e=loginrepository.ChangePassword(w,k);
	if(e==1) {
		return login;
	}else {
		return null;
	}
	}
@Override
public User updateUserDetails(User user) throws InvalidUserException {
	// TODO Auto-generated method stub
	
	if(userrepository.existsById(user.getUserId()))
	{
		String id=user.getUserId();
		String name=user.getFirstName();
		int k=userrepository.UpdateUser(name, id);
		if(k==1) {
			return user;
		}else {
			throw new InvalidUserException("user id is not available");
		}
	}
	return user;

}
@Override
public User getUserDetailsByemail(String email) {
	// TODO Auto-generated method stub
	 return  userrepository.getUserDetailsByemail(email);
}
}
