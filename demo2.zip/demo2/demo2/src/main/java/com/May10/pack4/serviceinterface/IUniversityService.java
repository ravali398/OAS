package com.May10.pack4.serviceinterface;
import java.util.List;

import com.May10.pack4.exception.InvalidUniversityException;
import com.May10.pack4.exception.UniversityCreationException;
import com.May10.pack4.model.University;

public interface IUniversityService {
	public University addUniversity(University university) throws UniversityCreationException ;
	public List<University> viewAllUniversityDetails();
	public List<University> getUniversityDetailsByCity(String city);
	public List<University> getUniversityDetailsByCollegeName(String collegeName);
	public int deleteUniversityById(int universityId);
	public University getUniversityById(int universityId)throws InvalidUniversityException;
	public int updateUniversity(University university) throws InvalidUniversityException;
}

