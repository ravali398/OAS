package com.May10.pack4.exception;

public class NoExistenceOfPaymentDetails extends Exception{
	public NoExistenceOfPaymentDetails()
	{
		super();
	}
	public NoExistenceOfPaymentDetails(String errorMsg)
	{
		super(errorMsg);
	}

}
