package com.May10.pack4.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.May10.pack4.model.Login;
import com.May10.pack4.model.User;

@Repository
public interface ILoginRepository extends JpaRepository<Login,String> {
	@Query(value="select * from login_table where login_id=?1",nativeQuery=true)
	public Login getloginDetailsById(String userid);
	@Transactional
	@Modifying
	@Query(value="delete from Login l where l.loginId=?1")
	public int deleteLoginDetailsById(String userid);
	@Transactional
	@Modifying
	@Query(value="update Login l set l.password=?1 where l.loginId=?2")
	public int ChangePassword(String password,String userid);
}
