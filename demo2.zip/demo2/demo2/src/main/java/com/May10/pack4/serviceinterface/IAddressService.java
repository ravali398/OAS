package com.May10.pack4.serviceinterface;

import java.util.List;
import com.May10.pack4.model.Address;

public interface IAddressService {
public Address addAddress(Address address);
public int deleteAddressById(int addressid);
public Address updateAddress(Address add);
public Address getAddressById(int id);
public List<Address> viewAllDetails();
}
