package com.May10.pack4.serviceinterface;

import java.util.List;

import com.May10.pack4.exception.CourseCreationException;
import com.May10.pack4.exception.InvalidCourseException;
import com.May10.pack4.model.Course;

public interface ICourseService {
	public Course addCourse(Course course)throws CourseCreationException;
	public List<Course> viewAllCourseDetails();
	public List<Course> getCourseDetailsByCourseName(String courseName);
	public List<Course> getCourseDetailsByCollegeName(String collegeName);
	public List<Course> getCourseDetailsByEligibility(String eligibility);
	public Course getCourseDetailsByCourseId(int courseId)throws InvalidCourseException;
	public int deleteCourseById(int courseId);
	public int deleteCourseByName(String CourseName);
	public int updateCourseDetails(Course course)throws InvalidCourseException;
	
}
