package com.May10.pack4.controller;

import java.util.List;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.May10.pack4.dao.IPaymentDao;
import com.May10.pack4.exception.InvalidPaymentException;
import com.May10.pack4.exception.NoExistenceOfPaymentDetails;
import com.May10.pack4.exception.PaymentCreationException;
import com.May10.pack4.model.Payment;
//RestController annotation is a combination of controller annotation and requestbody annotation
@CrossOrigin("*")
@RestController
public class IPaymentController {
//Here in the paymentcontroller paymentDao class is autowired 
//Autowiring is a method that marks a constructor, field, setter method, or config method as to be autowired by Spring's dependency injection facilities
@Autowired
private IPaymentDao pdao;
//logger is an interface that logging takes place through concrete implementations of this interface. 
Logger log=LoggerFactory.getLogger(IPaymentController.class);
//Annotation for mapping HTTP POST,GET,PUT,DELETE requests onto specific handler methods

@PostMapping(path="/createPayment")
public Payment addPayment(@Valid @RequestBody Payment payment)throws PaymentCreationException
 {
	Payment k=pdao.addPayment(payment);
	if(k!=null)
	{
		System.out.println("Payment is done");
		log.info("Payment is done");
	}
	else
	{
		System.out.println("not able to make payment");
		log.error("not able to make payment");
	}
	return k;
}

@GetMapping(path="/getAllPaymentDeatils")
public List<Payment> viewAllPaymentDetails(){
	log.info("get All Payment Details");
	return pdao.viewAllPaymentDetails();
}

@GetMapping(path="/getPaymentDetailsByPaymentId/{paymentId}")
public Payment getPaymentDetailsByPaymentId(@PathVariable int paymentId)throws InvalidPaymentException{
	log.info("get Payment Details By PaymentId");
	return pdao.getPaymentDetailsByPaymentId(paymentId);
}

@GetMapping(path="/getPaymentDetailsByapplicationId/{applicationId}")
public Payment getPaymentDetailsByApplicationId(@PathVariable int applicationId)throws InvalidPaymentException {
	log.info("get Payment Details By applicationId");
	return pdao.getPaymentDetailsByApplicationId(applicationId);
}

@GetMapping(path="/getPaymentDetailsByEmail/{emailId}")
public List<Payment> getPaymentDetailsByEmail(@PathVariable String emailId){
	log.info("get Payment Details By Email");
	return pdao.getPaymentDetailsByEmail(emailId);
}

@GetMapping(path="/getPaymentDetailsByStatus/{status}")
public List<Payment> getPaymentDetailsByStatus(@PathVariable String status){
	log.info("get Payment Details By Status");
	return pdao.getPaymentDetailsByStatus(status);
}

@DeleteMapping(path="/deletePayment/{id1}")
public int deletePaymentById(@PathVariable int id1) throws InvalidPaymentException{
	//return pdao.deletePaymentById(id1);
	int k1=pdao.deletePaymentById(id1);
	if(k1!=0)
	{
		
		System.out.println("Payment details  deleted");
		log.info("Payment details deleted");
		//log.info,log.error is mainly used to print the particular information in logger file
		
	}
	else
	{
		System.out.println("payment deatils not deleted");
		log.error("payment details not deleted");
		
	}
	return k1;
}

@PutMapping(path="/updatePayment/{paymentId}")
public int updatePaymentDetails(@Valid @RequestBody Payment payment, @PathVariable int paymentId) throws InvalidPaymentException {
	int k1=pdao.updatePaymentDetails(payment);
	if(k1!=0)
	{
		
		System.out.println("Payment details updated");
		log.info("Payment details updated");
		
	}
	else
	{
		System.out.println("payment details not updated");
		log.error("payment details not updated");
		
	}
	return k1;
  }
}
