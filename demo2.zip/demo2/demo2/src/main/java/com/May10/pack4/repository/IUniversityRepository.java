package com.May10.pack4.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;
import com.May10.pack4.model.University;

public interface IUniversityRepository extends JpaRepository<University,Integer> {
	
	
	@Transactional
	@Modifying
	@Query(value="delete from University u where u.universityId=?1")
	public int deleteUniversityById(int universityId);
	@Query(value="Select * from university_table where university_id=?1",nativeQuery=true)
	public University getUniversityById(int universityId);
	
	@Transactional
	@Modifying
	@Query(value="update University u set u.universityname=?1 where u.universityId=?2")
	public int updateUniversity(String universityname,int universityId);
	@Query(value="select * from university_table inner join college_table on university_table.university_id=college_table.university_university_id where college_table.college_name=?1",nativeQuery = true)
	public List<University> getUniversityDetailsByCollegeName(String collegeName);
	@Query(value="select * from university_table inner join address_table on university_table.address_address_id=address_table.address_id where address_table.city=?1",nativeQuery = true)
	public List<University> getUniversityDetailsByCity(String city);
	

}
