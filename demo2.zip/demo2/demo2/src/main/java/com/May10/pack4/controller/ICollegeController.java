package com.May10.pack4.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.May10.pack4.dao.ICollegeDao;
import com.May10.pack4.model.College;

@CrossOrigin("*")
@RestController
public class ICollegeController {
@Autowired 
private ICollegeDao collegedao;
@PostMapping(path="/createCollege")
public College addCollege(@RequestBody College college) {
	return collegedao.addCollege(college);
}
@GetMapping(path="/getAllCollegeDetails")
public List<College> viewAllCollegeDetails(){
	return collegedao.viewAllCollegeDetails();
}
@GetMapping("/getCollegedeatilsByName/{cName}")
public College getCollegeDetailsByName(@PathVariable String cName){
	return collegedao.getCollegeDetailsByName(cName);
	}
@GetMapping("/getCollegedeatilsByProgramName/{programName}")
public List<College> getCollegeDetailsByProgram(@PathVariable String programName){
	return collegedao.getCollegeDetailsByProgram(programName);}

@GetMapping("/getCollegedeatilsByCourseName/{courseName}")
public List<College> getCollegeDetailsByCourse(@PathVariable String courseName){
	return collegedao.getCollegeDetailsByCourse(courseName);}

@GetMapping("/getCollegedeatilsByBranchName/{branchName}")
public List<College> getCollegeDetailsByBranch(@PathVariable String branchName){
	return collegedao.getCollegeDetailsByBranch(branchName);}

@GetMapping("/getCollegeDetailsById/{collegeId}")
public College getCollegeDetailsById(@PathVariable int collegeId) {
return collegedao.getCollegeDetailsById(collegeId);
	 
}
@DeleteMapping("/deleteCollegeByName/{collegeName}")
public int deleteCollegeByName(@PathVariable String collegeName){
	return collegedao.deleteCollegeByName(collegeName);
}
@DeleteMapping("/deleteCollegeById/{collegeId}")
public int deleteCollegeById(@PathVariable int collegeId){
	return collegedao.deleteCollegeById(collegeId);
}
@PutMapping("/UpdateCollege/{collegeId}")
public int updateCollegeDetails(@RequestBody College college,@PathVariable int collegeId)  {
	return collegedao.updateCollegeDetails(college);
}
}
