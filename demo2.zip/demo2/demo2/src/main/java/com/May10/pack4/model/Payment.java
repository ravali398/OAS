package com.May10.pack4.model;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import javax.persistence.Id;
import javax.persistence.OneToOne;
//Entity specifies that class is an entity and table annotation is used to create the table for that particular class
//If table name not given default table name will be the class name
//id annotation specifies the primary key for that particular class
@Entity
@Table(name="payment_table")
public class Payment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int paymentId;
	//@Pattern(regexp="[A-Za-z0-9]{1}+[@]{1}+[A-Za-z]{5}+[.]{1}+[com]{1}",message="emailId is not correct")
	private String emailId;
	//@Range(min=1)
	
	private int applicationId;
	//private int applicationId;
	@NotNull(message="paymentAmount should not be null")
	@Range(min=1)
	private double paymentAmount;
	@NotNull(message="paymentDescription shouldnot be empty")
	private String paymentDescription;
	//Json format is Jacksonformat where we insert our date according to the pattern format mentioned
	/*@JsonFormat(pattern="dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="dd/MM/yyyy")*/
	private Date paymentDate;
	@NotBlank(message="paymentstatus shouldnot be empty")
	private String paymentStatus;
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public int getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}
	public double getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public String getPaymentDescription() {
		return paymentDescription;
	}
	public void setPaymentDescription(String paymentDescription) {
		this.paymentDescription = paymentDescription;
	}
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

}
