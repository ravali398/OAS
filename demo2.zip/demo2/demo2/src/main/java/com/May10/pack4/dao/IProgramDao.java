package com.May10.pack4.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.May10.pack4.model.Program;
import com.May10.pack4.repository.IProgramRepository;
import com.May10.pack4.serviceinterface.IProgramService;
@Service
public class IProgramDao implements IProgramService {
@Autowired
private IProgramRepository programrepository;
	@Override
	public Program addProgram(Program program) {
		// TODO Auto-generated method stub
		return programrepository.save(program);
	}

	@Override
	public List<Program> viewAllProgramDetails() {
		// TODO Auto-generated method stub
		return programrepository.findAll();
	}

	@Override
	public List<Program> getProgramDetailsByName(String programName) {
		// TODO Auto-generated method stub
		return programrepository.getProgramDetailsByName(programName);
	}

	@Override
	public List<Program> getProgramDetailsByEligibility(String eligibility) {
		// TODO Auto-generated method stub
		return programrepository.getProgramDetailsByEligibility(eligibility);
	}

	@Override
	public int deleteProgramById(int programid) {
		// TODO Auto-generated method stub
		return programrepository.deleteProgramById(programid);
	}

	@Override
	public int deleteProgamByName(String programName) {
		// TODO Auto-generated method stub
		return programrepository.deleteProgamByName(programName);
	}

	@Override
	public Program getProgramById(int programid) {
		// TODO Auto-generated method stub
		return programrepository.findById(programid).get();
	}

	@Override
	public int updateProgramStatus(Program program) {
		// TODO Auto-generated method stub
		int k=program.getProgramid();
		String name=program.getProgramName();
		return programrepository.updateProgramStatus(name,k) ;
	}

}
