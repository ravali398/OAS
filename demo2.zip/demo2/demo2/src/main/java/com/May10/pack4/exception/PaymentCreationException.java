package com.May10.pack4.exception;

import java.time.LocalDateTime;

public class PaymentCreationException extends Exception {

	public PaymentCreationException()
	{
		super();
	}
	public PaymentCreationException(String errorMsg)
	{
		super(errorMsg);
	}
		
}

