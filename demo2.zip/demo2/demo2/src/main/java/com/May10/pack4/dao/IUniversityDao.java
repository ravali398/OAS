package com.May10.pack4.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.May10.pack4.exception.UniversityCreationException;
import com.May10.pack4.model.University;
import com.May10.pack4.repository.IUniversityRepository;
import com.May10.pack4.serviceinterface.IUniversityService;
import com.May10.pack4.exception.InvalidPaymentException;
import com.May10.pack4.exception.InvalidUniversityException;
//@Service annotation provides as a specialization of @component,and allows the implemented classes to be autodetected through class path scanning.
@Service
public class IUniversityDao implements IUniversityService{
@Autowired
private IUniversityRepository repositoryuniversity;
@Override
public University addUniversity(University university) throws UniversityCreationException{
	// TODO Auto-generated method stub
	if(repositoryuniversity.existsById(university.getUniversityId()))
	{
		throw new UniversityCreationException("University Id is already Available");
	}
	else {
		return repositoryuniversity.save(university);
		
	}
	//University univer=repositoryUniversity.save(university);
	//return univer;
	
}

@Override
public List<University> viewAllUniversityDetails() {
	// TODO Auto-generated method stub
	return repositoryuniversity.findAll();
	//return null;
}

@Override
public List<University> getUniversityDetailsByCity(String city) {
	// TODO Auto-generated method stub
	return repositoryuniversity.getUniversityDetailsByCity(city);
	//return null;
}

@Override
public List<University> getUniversityDetailsByCollegeName(String collegeName) {
	// TODO Auto-generated method stub
	return repositoryuniversity.getUniversityDetailsByCollegeName(collegeName);
	//return null;
}

@Override
public int deleteUniversityById(int universityId) {
	// TODO Auto-generated method stub
	return repositoryuniversity.deleteUniversityById(universityId);
	//return 0;
	
}

@Override
public University getUniversityById(int universityId)throws InvalidUniversityException {
	// TODO Auto-generated method stub
	if(repositoryuniversity.existsById(universityId)) 
	{
	    return repositoryuniversity.findById(universityId).get();
    }
	else 
	{
	throw new InvalidUniversityException("university id is not available");
    }
}

@Override
public int updateUniversity(University university) throws InvalidUniversityException{
	// TODO Auto-generated method stub
	int status=0;
	if(repositoryuniversity.existsById(university.getUniversityId()))
	{
	int k=university.getUniversityId();
	String name=university.getUniversityname();
	return status=repositoryuniversity.updateUniversity(name,k);
	}
	else
	{
		throw new InvalidUniversityException("University Id is not available");
	}
}
}


