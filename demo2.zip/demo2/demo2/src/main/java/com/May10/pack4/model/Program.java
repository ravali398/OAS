package com.May10.pack4.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Id;

@Entity
@Table(name="Program_table")
public class Program {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
public int programid;
public String programName;
public String eligibility;
public String duration;
public String degreeOffered;

public int getProgramid() {
	return programid;
}
public void setProgramid(int programid) {
	this.programid = programid;
}
public String getProgramName() {
	return programName;
}
public void setProgramName(String programName) {
	this.programName = programName;
}
public String getEligibility() {
	return eligibility;
}
public void setEligibility(String eligibility) {
	this.eligibility = eligibility;
}
public String getDuration() {
	return duration;
}
public void setDuration(String duration) {
	this.duration = duration;
}
public String getDegreeOffered() {
	return degreeOffered;
}
public void setDegreeOffered(String degreeOffered) {
	this.degreeOffered = degreeOffered;
}

}
