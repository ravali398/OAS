package com.May10.pack4.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.May10.pack4.dao.IProgramDao;
import com.May10.pack4.model.Program;
@CrossOrigin("*")
@RestController
public class IProgramController {

@Autowired
private IProgramDao programdao;
@PostMapping(path="/createProgram")
public Program addProgram(@RequestBody Program program) {
	return programdao.addProgram(program);
}
@GetMapping(path="/getAllProgramDetails")
public List<Program> viewAllProgramDetails(){
	return programdao.viewAllProgramDetails();
}
@GetMapping("/getProgramDetailsByName/{programName}")
public List<Program> getProgramDetailsByName(@PathVariable String programName){
	return programdao.getProgramDetailsByName(programName);
}
@GetMapping("/getProgramDetailsByEligibity/{eligibility}")
public List<Program> getProgramDetailsByEligibility(@PathVariable String eligibility){
	return programdao.getProgramDetailsByEligibility(eligibility);
}

@DeleteMapping("/deleteProgramById/{programid}")
public int deleteProgramById(@PathVariable int programid) {
	return programdao.deleteProgramById(programid);
}
@DeleteMapping("/deleteProgramByName/{programName}")
public int deleteProgamByName(@PathVariable String programName) {
	return programdao.deleteProgamByName(programName);
}
@PutMapping("/updateProgramStatus/{programid}")
public int updateProgramStatus(@RequestBody Program program, @PathVariable int programid) {
	return programdao.updateProgramStatus(program);
}

@GetMapping("/getProgramById/{programid}")
public Program getProgramById(@PathVariable int programid) {
	return programdao.getProgramById(programid);
	 
}


}


