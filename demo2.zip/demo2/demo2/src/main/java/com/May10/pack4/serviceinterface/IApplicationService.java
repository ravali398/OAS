package com.May10.pack4.serviceinterface;

import java.util.List;

import com.May10.pack4.model.Application;

public interface IApplicationService {
public List<Application> viewAllApplicationDetails();
public List<Application> getApplicationDetailsbyemail(String emailId);
public Application addApplication(Application application);
public List<Application> getApplicationDeatilsByStatus(String applicationStatus);
public int deleteApplicationById(int applicationId);
public int deleteApplicationByEmail(String emailId);
public Application getApplicationById(int applicationId);
public int updateApplicationStatus(Application app);

}
