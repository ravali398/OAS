package com.May10.pack4.serviceinterface;
import java.util.List;

import com.May10.pack4.model.College;

public interface ICollegeService {
	public College addCollege(College college);
	public List<College> viewAllCollegeDetails();
	public College getCollegeDetailsById(int collegeId);
	public College getCollegeDetailsByName(String cName);
	public List<College> getCollegeDetailsByProgram(String programName);
	public List<College> getCollegeDetailsByCourse(String courseName);
	public List<College> getCollegeDetailsByBranch(String branchName);
	public int deleteCollegeById(int collegeId);
	public int deleteCollegeByName(String collegeName);
	public int updateCollegeDetails(College college);
	

}


