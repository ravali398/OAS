package com.May10.pack4.exception;

public class CreateUserException extends Exception{
	public CreateUserException()
	{
		super();
	}
	public CreateUserException(String errorMsg)
	{
		super(errorMsg);
	}
}
