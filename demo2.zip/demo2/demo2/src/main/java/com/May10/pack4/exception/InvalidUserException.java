package com.May10.pack4.exception;

public class InvalidUserException extends Exception{
	public InvalidUserException()
	{
		super();
	}
	public InvalidUserException(String errorMsg)
	{
		super(errorMsg);
	}
}
