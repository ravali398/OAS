package com.May10.pack4.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.May10.pack4.model.Application;
import com.May10.pack4.repository.IApplicationRepository;
import com.May10.pack4.serviceinterface.IApplicationService;
@Service
public class IApplicationDao implements IApplicationService{
@Autowired
private IApplicationRepository apprepository;
	@Override
	public List<Application> viewAllApplicationDetails() {
		// TODO Auto-generated method stub
		return apprepository.findAll();
	}

	@Override
	public List<Application> getApplicationDetailsbyemail(String email) {
		// TODO Auto-generated method stub
		return apprepository.getApplicationDetailsByEmail(email);
	}

	@Override
	public Application addApplication(Application application) {
		// TODO Auto-generated method stub
		return apprepository.save(application);
	}

	@Override
	public List<Application> getApplicationDeatilsByStatus(String Status) {
		// TODO Auto-generated method stub
		
		return apprepository.getApplicationByStatus(Status);
		
	}

	@Override
	public int deleteApplicationById(int applicationid) {
		// TODO Auto-generated method stub
		int k=apprepository.deleteAppById(applicationid);
		return k ;
	}

	@Override
	public int deleteApplicationByEmail(String email) {
		// TODO Auto-generated method stub
		int k=apprepository.deleteAppByEmail(email);
		return k;
	}

	@Override
	public Application getApplicationById(int applicationId) {
		// TODO Auto-generated method stub
   return apprepository.findById(applicationId).get(); 
			}

	@Override
	public int updateApplicationStatus(Application app) {
		// TODO Auto-generated method stub
		int k=app.getApplicationId();
		String applicantEmail=app.getEmailId();
		String highestQualification=app.getHighestQualification();
		int z= apprepository.UpdateAppstatus(applicantEmail,highestQualification,k);
		if(z==1) {
			return 1;
		}else {
			return 0;
		}
		
	}

}
