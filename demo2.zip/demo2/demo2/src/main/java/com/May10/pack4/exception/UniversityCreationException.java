package com.May10.pack4.exception;

public class UniversityCreationException extends Exception{
	
	public UniversityCreationException()
	{
		super();
	}
	public UniversityCreationException(String errorMsg)
	{
		super(errorMsg);
	}

}
