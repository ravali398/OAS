package com.May10.pack4.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.May10.pack4.dao.IUniversityDao;
import com.May10.pack4.exception.InvalidUniversityException;
import com.May10.pack4.exception.UniversityCreationException;
import com.May10.pack4.model.Branch;
import com.May10.pack4.model.University;
import com.May10.pack4.controller.IUniversityController;
@CrossOrigin("*")
//Annotated using response body and controller.
@RestController
public class IUniversityController {
	//It is used for adding dependency injection for Fields,setter methods and constructors.
	@Autowired
	private IUniversityDao dao;
	Logger log=LoggerFactory.getLogger(IUniversityController.class);
	//Annotation for mapping HTTP POST requests to create the data/details.
	@PostMapping(path="/addUniversity")
	//@Valid annotation for method level validation
	public University addUniversity(@Valid @RequestBody University university) throws UniversityCreationException {
		          University k= dao.addUniversity(university); 
		          if(k!=null)
		          {
		        	  
		        	  System.out.println("University is added");
		        	  log.info("University is added ");
		          }
		          else
		          {
		        	  
		        	  System.out.println("University is not added");
		        	  log.error("University is not added");
		          }
		          return k;
		
     }
	//Annotation for mapping HTTP GET requests to fetch the data/details.
	@GetMapping(path="/getUniversityDetails")
	public List<University> viewAllUniversityDetails(){
		log.info("viewAllUniversvityDetails");
		return dao.viewAllUniversityDetails();
	}
	//Annotation for mapping HTTP DELETE requests to delete the data/details.
	@DeleteMapping(path="/deleteUniversityById/{universityId}")
	//Path variable in the spring boot represents different kinds of parameters in the incoming request with the help of @pathvariable annotation.
	public int deleteUniversityById(@PathVariable int universityId){
		return dao.deleteUniversityById(universityId);
	}
	//Annotation for mapping HTTP UPDATE requests to update the data/details.
	@PutMapping(path="/UpdateUniversity/{universityId}")
	//@RequestBody annotation is applicable to handler methods of Spring controllers.
	public int updateUniversity(@Valid @RequestBody University university, @PathVariable int universityId) throws InvalidUniversityException{
		int k1=dao.updateUniversity(university);
		if(k1!=0)
        {
      	  System.out.println("University is Updated");
      	log.info("University is updated ");
        }
        else
        {
      	  System.out.println("University is not Updated");
      	  log.error("University is not Updated");
        }
        return k1;
	
	}
	@GetMapping(path="/getUniversityById/{universityId}")
	public University getUniversityById(@PathVariable int universityId)throws InvalidUniversityException {
		return dao.getUniversityById(universityId);
	}
	@GetMapping(path="/getUniversityCollege/{collegeName}")
	public List<University>getUniversityDetailsByCollegeName(@PathVariable String collegeName){
	return dao.getUniversityDetailsByCollegeName(collegeName);
	}
	@GetMapping(path="/getUniversityCity/{city}")
	public List<University> getUniversityDetailsByCity(@PathVariable String city){
		return dao. getUniversityDetailsByCity(city);
		
		
	}
	

	

}
