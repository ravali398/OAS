package com.May10.pack4.exception;

public class InvalidCourseException extends Exception {

	public InvalidCourseException()
	{
		super();
	}
	public InvalidCourseException(String errorMsg)
	{
		super(errorMsg);
	}
}


