package com.May10.pack4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.May10.pack4.dao.IApplicationDao;
import com.May10.pack4.model.Application;


@CrossOrigin("*")
@RestController
public class IApplicationController {
@Autowired 
private IApplicationDao appdao;
@PostMapping(path="/createApplication")
//RequestBody indicating a method parameter should be bound to the body of the web request.
public Application addApplication(@RequestBody Application application) {
	return appdao.addApplication(application);
}
@GetMapping(path="/getAllApplicationDetails")
public List<Application> viewAllApplicationDetails() {
	return appdao.viewAllApplicationDetails();
}
@GetMapping(path="/getApplicationById/{applicationId}")
public Application getApplicationById(@PathVariable int applicationId) {
	return appdao.getApplicationById(applicationId);
}
@GetMapping(path="/getApplicationDetailsByStatus/{applicationStatus}")
public List<Application> getApplicationDeatilsByStatus(@PathVariable String applicationStatus){
	return appdao.getApplicationDeatilsByStatus(applicationStatus);
}
@GetMapping(path="/getApplicationDetailsByEmail/{emailId}")
public List<Application> getApplicationDetailsbyemail(@PathVariable String emailId) {
	return appdao.getApplicationDetailsbyemail(emailId);
}
@DeleteMapping(path="/deleteApplicationById/{applicationId}")
public int deleteApplicationById(@PathVariable int applicationId) {
	return appdao.deleteApplicationById(applicationId);
}
@DeleteMapping(path="/deleteApplicationByEmail/{emailId}")
public int deleteApplicationByEmail(@PathVariable String emailId) {
return appdao.deleteApplicationByEmail(emailId);
}
@PutMapping(path="/updateApplicationStatus/{applicationId}")
public int updateApplicationStatus(@RequestBody Application app, @PathVariable int applicationId) {
	return appdao.updateApplicationStatus(app);
}
}

