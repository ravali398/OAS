package com.May10.pack4.exception;

public class InvalidUniversityException extends Exception{
	public InvalidUniversityException()
	{
		super();
	}
	public InvalidUniversityException(String errorMsg)
	{
		super(errorMsg);
	} 
	

}
