package com.May10.pack4.dao;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.May10.pack4.exception.InvalidPaymentException;
import com.May10.pack4.exception.NoExistenceOfPaymentDetails;
import com.May10.pack4.exception.PaymentCreationException;
import com.May10.pack4.model.Payment;
import com.May10.pack4.repository.IPaymentRepository;
import com.May10.pack4.serviceinterface.IPaymentService;
//Service has an operation as an interface that stands alone in the model, with no encapsulated state.
@Service
public class IPaymentDao implements IPaymentService{
//Autowired annotation marks a constructor, field, setter method, or config method as to be autowired by Spring's dependency injection facilities
@Autowired
private IPaymentRepository repositorypayment;
//override annotation indicates that a method declaration is intended to override a method declaration in a supertype
	@Override
	public Payment addPayment(Payment payment) throws PaymentCreationException {
		// TODO Auto-generated method stub
	    if(repositorypayment.existsById(payment.getPaymentId()))
		{
			throw new PaymentCreationException("Payment is already done");
		}
		else 
		{
		    return 	repositorypayment.save(payment);
		}
	}
	@Override
	public List<Payment> viewAllPaymentDetails(){
		// TODO Auto-generated method stub
		return repositorypayment.findAll();
		}

	@Override
	public List<Payment> getPaymentDetailsByEmail(String emailId) {
		// TODO Auto-generated method stub
		return repositorypayment.getPaymentDetailsByEmailId(emailId);
	}
	@Override
	public Payment getPaymentDetailsByPaymentId(int paymentId) throws InvalidPaymentException {
		// TODO Auto-generated method stub
		if(repositorypayment.existsById(paymentId)) 
		{
		    return repositorypayment.findById(paymentId).get();
	    }
		else 
		{
		throw new InvalidPaymentException("Payment id is not available");
	    }
	}

	@Override
	public Payment getPaymentDetailsByApplicationId(int applicationId) throws InvalidPaymentException {
		// TODO Auto-generated method stub
		  Payment k= repositorypayment.getPaymentDetailsByApplicationId(applicationId);
		  if(k!=null) {
			  return repositorypayment.getPaymentDetailsByApplicationId(applicationId);
		              }
		else 
		{
			throw new InvalidPaymentException("Payment id is not available");
        }
	}

	@Override
	public List<Payment> getPaymentDetailsByStatus(String paymentStatus) {
		// TODO Auto-generated method stub
		return repositorypayment.getPaymentDetailsByStatus(paymentStatus);
	}

	@Override
	public int deletePaymentById(int paymentById) throws InvalidPaymentException {
		// TODO Auto-generated method stub
		if(repositorypayment.existsById(paymentById))
		{
		   return repositorypayment.deletePaymentById(paymentById);
	    }
		else 
		{
		   throw new InvalidPaymentException("Payment id is not available");
	    }
	}

	@Override
	public int updatePaymentDetails(Payment payment)throws InvalidPaymentException {
		// TODO Auto-generated method stub	
			int status=0;
			if(repositorypayment.existsById(payment.getPaymentId()))
			{
				int k=payment.getPaymentId();
				double a=payment.getPaymentAmount();
				String e=payment.getEmailId();
				String s=payment.getPaymentDescription();        
				return status= repositorypayment.updatePayment(a,e,s,k);
		 	}
			{
				throw new InvalidPaymentException("Payment id is not available");
			}
	}

}


