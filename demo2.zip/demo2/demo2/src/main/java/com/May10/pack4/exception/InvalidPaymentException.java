package com.May10.pack4.exception;

public class InvalidPaymentException  extends Exception{
	public InvalidPaymentException()
	{
		super();
	}
	public InvalidPaymentException(String errorMsg)
	{
		super(errorMsg);
	}
}
