 package com.May10.pack4.dao;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.May10.pack4.exception.CourseCreationException;
import com.May10.pack4.exception.InvalidCourseException;
import com.May10.pack4.exception.InvalidPaymentException;
import com.May10.pack4.model.Course;
import com.May10.pack4.repository.ICourseRepository;
import com.May10.pack4.serviceinterface.ICourseService;
//@Service annotation provides as a specialization of @component,and allows the implemented classes to be autodetected through class path scanning.
@Service
public class ICourseDao implements ICourseService{
	@Autowired
	private ICourseRepository repositorycourse;
	//@Override indicates that a method declaration is intended to override amethod declaration in a supertype.
	@Override
	public Course addCourse(Course course) throws CourseCreationException {
		// TODO Auto-generated method stub
		if(repositorycourse.existsById(course.getCourseId()))
		{
			throw new CourseCreationException("Course Id already existing");
		}
		else {
		return repositorycourse.save(course);
		}
	}

	@Override
	public List<Course> viewAllCourseDetails() {
		// TODO Auto-generated method stub
		return repositorycourse.findAll();
	}

	@Override
	public List<Course> getCourseDetailsByCourseName(String courseName) {
		// TODO Auto-generated method stub
		return repositorycourse.getCourseDetailsByCourseName(courseName);
		
	}

	@Override
	public List<Course> getCourseDetailsByCollegeName(String collegeName) {
		// TODO Auto-generated method stub
		return repositorycourse.getCourseDetailsByCollegeName(collegeName);
	}

	@Override
	public List<Course> getCourseDetailsByEligibility(String eligiblity) {
		// TODO Auto-generated method stub
		return repositorycourse.getCourseDetailsByEligibility(eligiblity);
	}

	@Override
	public Course getCourseDetailsByCourseId(int courseId)throws InvalidCourseException {
		// TODO Auto-generated method stub
		if(repositorycourse.existsById(courseId)) 
		{
		    return repositorycourse.findById(courseId).get();
	    }
		else 
		{
		throw new InvalidCourseException("Course id is not available");
	    }
	}

	@Override
	public int deleteCourseById(int courseId) {
		// TODO Auto-generated method stub
		return repositorycourse.deleteCourseById(courseId);
	}

	@Override
	public int deleteCourseByName(String courseName) {
		// TODO Auto-generated method stub
		return repositorycourse.deleteCourseByName(courseName);
	}

	@Override
	public int updateCourseDetails(Course course) throws InvalidCourseException {
		// TODO Auto-generated method stub
		int status=0;
		if(repositorycourse.existsById(course.getCourseId()))
		{
		int k=course.getCourseId();
		String e=course.getEligiblity();
		return status= repositorycourse.updateCourseDetails(e,k);
		}
		{
			throw new InvalidCourseException("Course id is not existing");
		}
	}

	

	

}