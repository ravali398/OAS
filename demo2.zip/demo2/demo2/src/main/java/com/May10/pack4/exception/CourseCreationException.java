package com.May10.pack4.exception;

public class CourseCreationException extends Exception{
	
	public CourseCreationException()
	{
		super();
	}
	public CourseCreationException(String errorMsg)
	{
		super(errorMsg);
	}
}
