package com.May10.pack4.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Id;
@Entity
@Table (name="Branch_table")
public class Branch {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private int branchId;
private String branchName;
private String branchDescription;
public int getBranchId() {
	return branchId;
}
public void setBranchId(int branchId) {
	this.branchId = branchId;
}
public String getBranchName() {
	return branchName;
}
public void setBranchName(String branchName) {
	this.branchName = branchName;
}
public String getBranchDescription() {
	return branchDescription;
}
public void setBranchDescription(String branchDescription) {
	this.branchDescription = branchDescription;
}

}
