package com.May10.pack4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.May10.pack4.dao.IAddressDao;
import com.May10.pack4.model.Address;
@CrossOrigin("*")
@RestController
public class IAddressController {
@Autowired
private IAddressDao dao;
@PostMapping(path="/createAddress")
public Address addAddress(@RequestBody Address address) {
	return dao.addAddress(address);
}
@GetMapping(path="/getAddressById/{id2}")
public Address getAddressById(@PathVariable int id2) {
	return dao.getAddressById(id2);
}
@GetMapping(path="/getAddressDetails")
public List<Address> viewAllDetails(){
	return dao.viewAllDetails();
}
@DeleteMapping(path="/deleteAddress/{id1}")
public int deleteAddressById(@PathVariable int id1) {
	return dao.deleteAddressById(id1);
}
@PutMapping(path="/updateAddress/{addId}")
public Address updateAddress(@RequestBody Address add, @PathVariable int addId) {
	return dao.updateAddress(add);
}
}
