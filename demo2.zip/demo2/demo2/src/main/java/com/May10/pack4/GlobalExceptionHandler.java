package com.May10.pack4;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.May10.pack4.exception.PaymentCreationException;
import com.May10.pack4.exception.InvalidUniversityException;
import com.May10.pack4.exception.UniversityCreationException;
import com.May10.pack4.exception.CourseCreationException;
import com.May10.pack4.exception.CreateUserException;
import com.May10.pack4.exception.ErrorMessage;
import com.May10.pack4.exception.InvalidCourseException;
import com.May10.pack4.exception.InvalidPaymentException;
import com.May10.pack4.exception.InvalidUserException;
import com.May10.pack4.exception.NoExistenceOfPaymentDetails;
//Controller Advice is mainly used to declare exception handling, model attributes methods across multiple @controller classes
@ControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(InvalidPaymentException.class)
	public @ResponseBody ErrorMessage checkInvalidPaymentException(InvalidPaymentException e)
	
	{
		ErrorMessage error1=new ErrorMessage(LocalDateTime.now(), e.getMessage());
		return error1;
	}
	//ResponseBody that indicates a method return value should be bound to the web response body
	@ExceptionHandler(PaymentCreationException.class)
	public @ResponseBody ErrorMessage checkPaymentCreationException(PaymentCreationException e)
	
	{
		ErrorMessage error1=new ErrorMessage(LocalDateTime.now(), e.getMessage());
		return error1;
	}
	@ExceptionHandler(NoExistenceOfPaymentDetails.class)
	public @ResponseBody ErrorMessage checkNoExistenceOfPaymentDetails(NoExistenceOfPaymentDetails e)
	
	{
		ErrorMessage error1=new ErrorMessage(LocalDateTime.now(), e.getMessage());
		return error1;
	}
	@ExceptionHandler(CreateUserException.class)
	public @ResponseBody ErrorMessage checkUserCreationException(CreateUserException e)
	
	{
		ErrorMessage error1=new ErrorMessage(LocalDateTime.now(), e.getMessage());
		return error1;
	}
	@ExceptionHandler(InvalidUserException.class)
	public @ResponseBody ErrorMessage checkInvalidUserException(InvalidUserException e)
	
	{
		ErrorMessage error1=new ErrorMessage(LocalDateTime.now(), e.getMessage());
		return error1;
	}
	//ExceptionHandler is handling exceptions in specific handler classes and/or handler methods.
		@ExceptionHandler(InvalidCourseException.class)
		
		//ResponseBody indicates a method return value should be bound to the web response body. Supported for annotated handler methods
		public @ResponseBody ErrorMessage checkInvalidCourseException(InvalidCourseException e)
		
		{
			ErrorMessage error1=new ErrorMessage(LocalDateTime.now(), e.getMessage());
			return error1;
		}
		@ExceptionHandler(CourseCreationException.class)
		public @ResponseBody ErrorMessage checkCourseCreationException(CourseCreationException e)
		
		{
			ErrorMessage error1=new ErrorMessage(LocalDateTime.now(), e.getMessage());
			return error1;
		}
		//ExceptionHandler is handling exceptions in specific handler classes and/or handler methods.
		@ExceptionHandler(InvalidUniversityException.class)
		//ResponseBody indicates a method return value should be bound to the web response body. Supported for annotated handler methods
		public @ResponseBody ErrorMessage checkInvalidUniversityException(InvalidUniversityException e)
		
		{
			ErrorMessage error1=new ErrorMessage(LocalDateTime.now(), e.getMessage());
			return error1;
		}
		//handling exceptions in specific handler classes and/or handler methods.-Exception Handler.
		@ExceptionHandler(UniversityCreationException.class)
		public @ResponseBody ErrorMessage checkUniversityCreationException(UniversityCreationException e)
		
		{
			ErrorMessage error1=new ErrorMessage(LocalDateTime.now(), e.getMessage());
			return error1;
		}
	
	
   //validation
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public @ResponseBody ErrorMessage checkPaymentValidation(MethodArgumentNotValidException e)
	
	{
		ErrorMessage error1=new ErrorMessage(LocalDateTime.now(),e.getMessage(),e.getBindingResult().toString());
		return error1;
	}
	
	
	
	
	
	
		 
	}
