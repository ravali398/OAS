package com.May10.pack4.controller;

import java.util.List;


import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.May10.pack4.dao.IUserDao;
import com.May10.pack4.exception.CreateUserException;
import com.May10.pack4.exception.InvalidUserException;
import com.May10.pack4.exception.PaymentCreationException;
import com.May10.pack4.model.Login;
import com.May10.pack4.model.Payment;
import com.May10.pack4.model.User;
import org.springframework.web.bind.annotation.CrossOrigin;
@CrossOrigin("*")
@RestController
public class IUserController {
	
@Autowired 
private IUserDao userdao;
Logger log=LoggerFactory.getLogger(IUserController.class);
@PostMapping(path="/createUser")
public User addUser(@RequestBody User user)throws CreateUserException {
	   System.out.println(user.getUserId());
	   System.out.println(user.getLogin().getLoginId());
	   
		User k=userdao.addUserDetails(user);
		if(k!=null)
		{
			
			System.out.println("User is done");
			log.info("User is done");

			
		}
		else
		{
			System.out.println("not able to make User");
			log.error("not able to make user");
		}
		return k;

	}
@PostMapping(path="/createLogin")
public Login addLoginDetails(@RequestBody Login login) {
	return userdao.addLoginDetails(login);
}
@GetMapping("/getUserdetailsById/{Id}")
public User getUserDetailsById(@PathVariable String Id){
	return userdao.getUserDetailsById(Id);
}
@GetMapping("/getLogindetailsById/{userid}")
public Login getLoginDetailsById(@PathVariable String userid){
	return userdao.getLoginDetailsById(userid);
}
@GetMapping("/getAllUserDetails")
public List<User> getAllUserDetails(){
	return userdao.getAllUserDetails();
}
@GetMapping("/getAllLoginDetails")
public List<Login> getAllLoginDetails(){
	return userdao.getAllLoginDetails();
}

@DeleteMapping("/deleteUserdetailsById/{Id}")
public User deleteUserDetailsById(@PathVariable String Id) {
	return userdao.deleteUserDetailsById(Id);
}
@DeleteMapping("/deleteLogindetailsById/{userid}")
public Login deleteLoginDetailsById(@PathVariable String userid) {
	return userdao.deleteLoginDetailsById(userid);
}
@PutMapping("/UpdatePassword/{login}/{userid}")
public Login changePassword(@RequestBody Login login,@PathVariable String userid) {
	return userdao.changePassword(login);
}
@PutMapping("/ResetPassword/{login}/{userid}")
public Login resetPassword(@RequestBody Login login,@PathVariable String userid) {
	return userdao.resetPassword(login);
}
@PutMapping("/UpdateUserdetails/{user}/{userId}")
public User updateUserDetails(@RequestBody User user,@PathVariable String userId) throws InvalidUserException{
	User k1=userdao.updateUserDetails(user);
	if(k1!=null)
	{
		
		System.out.println("User details updated");
		log.info("User details updated");
		
	}
	else
	{
		System.out.println("user details not updated");
		log.error("user details not updated");
		
	}
	return k1;
	
}
}

