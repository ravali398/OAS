package com.May10.pack4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.May10.pack4.dao.IBranchDao;
import com.May10.pack4.model.Application;
import com.May10.pack4.model.Branch;
@CrossOrigin("*")
@RestController
public class IBranchController {
@Autowired 
private IBranchDao branchdao;
@PostMapping(path="/createBranch")
public boolean addBranch(@RequestBody Branch branch) {
	return branchdao.addBranch(branch);
}
@GetMapping(path="/getAllBranchDetails")
public List<Branch> viewAllBranchDetails(){
	return branchdao.viewAllBranchDetails();
}
@GetMapping("/getBranchdeatilsByName/{branchName}")
public List<Branch> getBranchDetailsByName(@PathVariable String branchName){
	return branchdao.getBranchDetailsByName(branchName);
}
@GetMapping("/getBranchById/{branchId}")
public Branch getBranchById(@PathVariable int branchId) {
return branchdao.getBranchById(branchId);
	 
}
@DeleteMapping("/deleteBranchByName/{branchName}")
public int deleteBranchByName(@PathVariable String branchName) {
	return branchdao.deleteBranchByName(branchName);
}
@PutMapping("/updateBranch/{branchId}")
public int updateBranch(@RequestBody Branch branch, @PathVariable int branchId) {
	return branchdao.updateBranch(branch);
}
}
