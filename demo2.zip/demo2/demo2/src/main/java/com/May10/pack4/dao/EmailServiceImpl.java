package com.May10.pack4.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.May10.pack4.model.User;
import com.May10.pack4.repository.IUserRepository;
import com.May10.pack4.serviceinterface.EmailService;


@Service
public class EmailServiceImpl implements EmailService {
@Autowired private JavaMailSender javaMailSender;		 
@Value("${spring.mail.username}") private String sender;
@Autowired private IUserRepository repos;
@Autowired private EmailService s;
public String sendSimpleMail(String mail){ 		        
		        try {
		        	SimpleMailMessage mailMessage= new SimpleMailMessage();
		            mailMessage.setFrom(sender);
		            mailMessage.setTo(mail);
		            mailMessage.setText(s.getOTPbyEmail(mail));
		            mailMessage.setSubject("One time password");      
		            javaMailSender.send(mailMessage);
		            return "Mail Sent Successfully...";
		            }
		 		catch (Exception e) {
		            return "Error while Sending Mail" + " "+e;
		            }
		    }
@Override
public String getOTPbyEmail(String email) {
	// TODO Auto-generated method stub
	User p=repos.getUserDetailsByemail(email);   	   
	String username=p.getFirstName();
    String phone=p.getMobileNumber();
    String phoneno=phone.substring(0,3);
    String msg=username+""+phoneno;
    msg="Your OTP is"+""+msg;
    return msg;
}


			
	}
