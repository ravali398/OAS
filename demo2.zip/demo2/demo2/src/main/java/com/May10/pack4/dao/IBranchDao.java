package com.May10.pack4.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.May10.pack4.model.Branch;
import com.May10.pack4.repository.IBranchRepository;
import com.May10.pack4.serviceinterface.IBranchService;
@Service
public class IBranchDao implements IBranchService{
	@Autowired
	private IBranchRepository repositorybranch;
	@Override
	public boolean addBranch(Branch branch) {
		// TODO Auto-generated method stub
		Branch b=repositorybranch.save(branch);
		if(b!=null) {
			return true;
		}else {
			return false;
		}
	}

	@Override
	public List<Branch> viewAllBranchDetails() {
		// TODO Auto-generated method stub
		return repositorybranch.viewAllBranchDetails();
		//return repositorybranch.findAll();
	}

	@Override
	public List<Branch> getBranchDetailsByName(String branchName) {
		// TODO Auto-generated method stub
		return repositorybranch.getBranchDetailsByName(branchName);
	}

	@Override
	public int deleteBranchById(int branchId) {
		// TODO Auto-generated method stub
		return repositorybranch.deleteBranchById(branchId);
	}

	@Override
	public Branch getBranchById(int branchId) {
		// TODO Auto-generated method stub
		Branch b= repositorybranch.findById(branchId).get();
		return b;
	}

	@Override
	public int deleteBranchByName(String branchName) {
		// TODO Auto-generated method stub
		return repositorybranch.deleteBranchByName(branchName);
	}

	@Override
	public int updateBranch(Branch branch) {
		// TODO Auto-generated method stub
		int k=branch.getBranchId();
		String branchDescription=branch.getBranchDescription();
		int z= repositorybranch.UpdateBranch(branchDescription, k);
		if(z==1) {
			return 1;
		}else {
			return 0;
		}
	}

}
