package com.May10.pack4.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.May10.pack4.model.Branch;
import com.May10.pack4.model.College;
import com.May10.pack4.model.Course;
import com.May10.pack4.model.University;
@Repository
public interface ICollegeRepository extends JpaRepository<College,Integer>{
	
	@Query(value="select * from college_table where college_name=?1",nativeQuery=true)
	public College getCollegeDetailsByName(String collegeName);
	
   @Query(value="select * from college_table col where col.college_id=(select c.college_college_id from college_table_program_list c inner join program_table p ON c.program_list_programid=p.programid where p.program_name=?1)",nativeQuery=true)
	public List<College> getCollegeDetailsByProgram(String programName);
   
   //@Query(value="select * from college_table col inner join course_table c on where col.college_id=c.college_college_id where c.course_name=?1",nativeQuery=true)
   @Query(value="select * from college_table col where col.college_id=(select c.college_college_id from college_table_course_list c inner join course_table p ON c.course_list_course_id=p.course_id where p.course_name=?1)",nativeQuery=true)
   public List<College> getCollegeDetailsByCourse(String courseName);
   

 // @Query(value="select * from college_table col where col.college_id=(select c.college_college_id from college_table_branch_list c inner join branch_table b ON c.branch_list_branch_id=b.branch_id where b.branch_name=?1)",nativeQuery=true)
   @Query(value="select * from college_table col where col.college_id=(select c.college_college_id from college_table_branch_list c inner join branch_table p ON c.branch_list_branch_id=p.branch_id where p.branch_name=?1)",nativeQuery=true)
   public List<College> getCollegeDetailsByBranch(String branchName);
	@Transactional
	@Modifying
	@Query(value="delete from College c where c.collegeId=?1")
	public int deleteCollegeById(int collegeId);
	@Transactional
	@Modifying
	@Query(value="delete from College c where c.collegeName=?1")
	public int deleteCollegeByName(String  collegeName);
	@Transactional
	@Modifying
	@Query(value="update College c set c.collegeName=?1 where c.collegeId=?2")
	public int updateCollegeDetails(String collegeName,int collegeId );
}


