package com.May10.pack4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RestController;

import com.May10.pack4.serviceinterface.EmailService;
@CrossOrigin("*")
@RestController
public class EmailController {
	 @Autowired private EmailService emailService;
	
	 
	    // Sending a simple Email
	    @GetMapping("/sendMail/{mail}")
	    public String sendMail(@PathVariable  String mail)
	    {
	         	
	        String status= emailService.sendSimpleMail(mail);
	 
	        return status;
	    }   
	    
	    @GetMapping(path="/getEmail/{email}")    
	    public String getOTPbyEmail(@PathVariable String email)
	    {  	    	    	    	    
		
	    return emailService.getOTPbyEmail(email);
	    }
}
