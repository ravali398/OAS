package com.May10.pack4.serviceinterface;



public interface EmailService {
	public String sendSimpleMail(String mail);
	 public String getOTPbyEmail(String email);
}
