package com.May10.pack4.model;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Range;
//@Entity annotation is used to the class.
@Entity
//@Table annotation specifies the name of the database table.
@Table(name="university_table")
public class University {
	//@Id annotation specifies the primary key of an entity.
	@Id
	//The annotated has to be in the appropriate range. Apply on numeric values or string representation of the numeric value.
	@Range(min=1)
	public int universityId;
	//not be null
	@NotBlank(message="name cannot be blank")
	public String universityname;
	@OneToOne(cascade=CascadeType.ALL)
	public Address address;
	@OneToMany(cascade=CascadeType.ALL)
	public List<College>collegeList;
	
	public int getUniversityId() {
		return universityId;
	}
	public void setUniversityId(int universityId) {
		this.universityId = universityId;
	}
	
	public String getUniversityname() {
		return universityname;
	}
	public void setUniversityname(String universityname) {
		this.universityname = universityname;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public List<College> getCollegeList() {
		return collegeList;
	}
	public void setCollegeList(List<College> collegeList) {
		this.collegeList = collegeList;
	}
	
	
	
	}
