package com.May10.pack4.serviceinterface;

import java.util.List;

import org.springframework.web.bind.MethodArgumentNotValidException;

import com.May10.pack4.exception.NoExistenceOfPaymentDetails;
import com.May10.pack4.exception.InvalidPaymentException;
import com.May10.pack4.exception.PaymentCreationException;
import com.May10.pack4.model.Payment;

public interface IPaymentService {
	public Payment addPayment(Payment payment)throws PaymentCreationException;
	public List<Payment> viewAllPaymentDetails();
	public List<Payment> getPaymentDetailsByEmail(String emailId);
	public Payment getPaymentDetailsByPaymentId(int paymentId) throws InvalidPaymentException;
	public Payment getPaymentDetailsByApplicationId(int applicationId) throws InvalidPaymentException;
	public List<Payment> getPaymentDetailsByStatus(String paymentStatus);
	public int deletePaymentById(int paymentById) throws InvalidPaymentException;
	public int updatePaymentDetails(Payment payment) throws InvalidPaymentException;

}