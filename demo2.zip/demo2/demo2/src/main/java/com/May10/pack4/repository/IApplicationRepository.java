package com.May10.pack4.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.May10.pack4.model.Application;
@Repository
public interface IApplicationRepository extends JpaRepository<Application, Integer>{
	@Transactional
	@Modifying
	@Query(value="delete from Application a where a.applicationId=?1")
	public int deleteAppById(int applicationId);
	@Transactional
	@Modifying
	@Query(value="delete from Application a where a.emailId=?1")
	public int deleteAppByEmail(String  emailId);
	@Query(value="select * from application_table where application_status=?1",nativeQuery=true)
	public List<Application> getApplicationByStatus(String status);
	@Query(value="select * from application_table where email_id=?1",nativeQuery=true)
	public List<Application> getApplicationDetailsByEmail(String email);
	@Transactional
	@Modifying
	@Query(value="update Application a set a.applicantFullName=?1,a.highestQualification=?2 where a.applicationId=?3")
	public int UpdateAppById(String applicantFullName,String highestQualification,int applicationId);
	@Transactional
	@Modifying
	@Query(value="update Application a set a.emailId=?1,a.highestQualification=?2 where a.applicationId=?3")
	public int UpdateAppstatus(String emailId,String highestQualification,int applicationId);
}
