package com.May10.pack4.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.May10.pack4.dao.ICourseDao;
import com.May10.pack4.exception.CourseCreationException;
import com.May10.pack4.exception.InvalidCourseException;
import com.May10.pack4.model.Course;
@CrossOrigin("*")
//Annotated using response body and controller.
@RestController
public class ICourseController {
	//It is used for adding dependency injection for Fields,setter methods and constructors.
@Autowired
private ICourseDao daocourse;
//Annotation for mapping HTTP POST requests to create the data/details.
Logger log=LoggerFactory.getLogger(ICourseController.class);
@PostMapping(path="/createcourse")
//@Valid annotation for method level validation.
public Course addCourse(@Valid @RequestBody Course course) throws CourseCreationException{
	Course k= daocourse.addCourse(course);
	if(k!=null)
	{
		System.out.println("Course is added");
		log.info("Course is added ");
	}
	else
	{
		System.out.println("Not able to add course");
		log.error("Course is not added ");
	}
	return k;
}
//Annotation for mapping HTTP GET requests to fetch the data/details.
@GetMapping(path="/getAllCourseDetails")
public List<Course> viewAllCourseDetails(){
	return daocourse.viewAllCourseDetails();
}
@GetMapping(path="/getCourseDetailsByCourseName/{courseName}")
public List<Course> getCourseDetailsByCourseName(@PathVariable String courseName){
	return daocourse.getCourseDetailsByCourseName(courseName);
}
@GetMapping(path="/getCourseDetailsByCollegeName/{collegeName}")
public List<Course> getCourseDetailsByCollegeName(@PathVariable String collegeName){
	return daocourse.getCourseDetailsByCollegeName(collegeName);
}

@GetMapping(path="/getCourseDetailsByEligibility/{eligiblity}")
public List<Course> getCourseDetailsByEligibility(@PathVariable String eligiblity) {
	return daocourse.getCourseDetailsByEligibility(eligiblity);
}

@GetMapping(path="/getCourseDetailsByCourseId/{courseId}")
public Course getCourseDetailsByCourseId(@PathVariable int courseId)throws InvalidCourseException {
	// TODO Auto-generated method stub
	Course course=daocourse.getCourseDetailsByCourseId(courseId);
	if(course!=null)
	{
		
		System.out.println("course details");
		log.info("course details");
		return course;
		//log.info,log.error is mainly used to print the particular information in logger file
		
	}
	else
	{
		System.out.println("Id not avaliable");
		log.error("Id not avaliable");
		return null;
		
	}
	
}
//Annotation for mapping HTTP DELETE requests to delete the data/details.
@DeleteMapping(path="/deleteCourse/{courseId}")
public int deleteCourseById(@PathVariable int courseId) {
	return daocourse.deleteCourseById(courseId);
		
	}
//Path variable in the spring boot represents different kinds of parameters in the incoming request with the help of @pathvariable annotation.
@DeleteMapping(path="/deleteCourseByName/{courseName}")
public int deleteCourseByName(@PathVariable String courseName) {
	return daocourse.deleteCourseByName(courseName);
}
//Annotation for mapping HTTP UPDATE requests to update the data/details.
@PutMapping("/UpdateCourseDetails/{courseId}")
//@RequestBody annotation is applicable to handler methods of Spring controllers
public int updateCourseDetails(@Valid @RequestBody Course course,@PathVariable int courseId)throws InvalidCourseException {
	int k1= daocourse.updateCourseDetails(course);
	if(k1!=0) {
		System.out.println("Course details updated");
		log.info("Course is updated ");
	}
	else {
		System.out.println("Course details are not updated");
		log.error("Course is not updated ");
	}
	return k1;

}
}


