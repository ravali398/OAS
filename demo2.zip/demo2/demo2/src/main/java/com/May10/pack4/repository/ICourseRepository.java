package com.May10.pack4.repository;
import com.May10.pack4.model.Course;

import java.util.List;

import javax.transaction.Transactional;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.jpa.repository.Modifying;
//import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
//@Repository Annotation is used for  encapsulating storage,retrieval, and search behavior on objects.
@Repository
public interface ICourseRepository extends JpaRepository<Course,Integer> {
	//This annotation is used to declare finder queries directly on repository methods= Query.
	@Query(value="select * from course_table where course_name=?1",nativeQuery=true)
	public List<Course> getCourseDetailsByCourseName(String courseName);
	
	@Query(value="select * from course_table inner join college_table on course_table.college_college_id=college_table.college_id where college_table.college_name=?1",nativeQuery=true)
	public List<Course> getCourseDetailsByCollegeName(String collegeName);
	
	@Query(value="select * from course_table where eligiblity=?1",nativeQuery=true)
	public List<Course> getCourseDetailsByEligibility(String eligiblity);
	//To configure the transactional behavior of a method=Transactional.
	@Transactional
	//The annotation is used in modifying query as that changes the way it needs to be executed.
	@Modifying
	@Query(value="delete from Course c where c.courseId=?1")
	public int deleteCourseById(int courseId);
	
	@Transactional
	@Modifying
	@Query(value="delete from Course c where c.courseName=?1")
	public int deleteCourseByName(String courseName);
	
	@Transactional
	@Modifying
	@Query(value="update Course c set c.eligiblity=?1 where c.courseId=?2")
	public int updateCourseDetails(String eligiblity, int courseId);
	
	
	
	
}