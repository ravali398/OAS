
package com.May10.pack4.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.May10.pack4.model.College;
import com.May10.pack4.repository.ICollegeRepository;
import com.May10.pack4.serviceinterface.ICollegeService;
@Service
public class ICollegeDao implements ICollegeService{
@Autowired
	private ICollegeRepository collegerepository;
	@Override
	public College addCollege(College college) {
		// TODO Auto-generated method stub
		return collegerepository.save(college);
	}

	@Override
	public List<College> viewAllCollegeDetails() {
		// TODO Auto-generated method stub
		return collegerepository.findAll();
	}

	@Override
	public List<College> getCollegeDetailsByProgram(String programName) {
		// TODO Auto-generated method stub
		return collegerepository.getCollegeDetailsByProgram(programName);
	}

	@Override
	public List<College> getCollegeDetailsByCourse(String courseName) {
		// TODO Auto-generated method stub
		return collegerepository.getCollegeDetailsByCourse(courseName);
	}

	@Override
	public List<College> getCollegeDetailsByBranch(String branchName) {
		// TODO Auto-generated method stub
		return collegerepository.getCollegeDetailsByBranch(branchName);
	}

	@Override
	public College getCollegeDetailsByName(String cName) {
		// TODO Auto-generated method stub
		return collegerepository.getCollegeDetailsByName(cName);
	}

	@Override
	public int deleteCollegeById(int collegeId) {
		// TODO Auto-generated method stub
		return collegerepository.deleteCollegeById(collegeId);
	}

	@Override
	public int deleteCollegeByName(String collegeName) {
		// TODO Auto-generated method stub
		return collegerepository.deleteCollegeByName(collegeName);
	}

	@Override
	public int updateCollegeDetails(College college) {
		// TODO Auto-generated method stub
		int k=college.getCollegeId();
		String name=college.getCollegeName();
		 return collegerepository.updateCollegeDetails(name, k);
		 
	}

	@Override	
	public College getCollegeDetailsById(int collegeId) {
		// TODO Auto-generated method stub
		return collegerepository.findById(collegeId).get();
	}

}