package com.May10.pack4.serviceinterface;

import java.util.List;

import com.May10.pack4.exception.CreateUserException;
import com.May10.pack4.exception.InvalidUserException;
import com.May10.pack4.model.Login;
import com.May10.pack4.model.User;

public interface IUserService {
	public User addUserDetails(User user) throws CreateUserException;
	public Login addLoginDetails(Login login);
	public List<User> getAllUserDetails();
	public List<Login> getAllLoginDetails();
	public User getUserDetailsById(String userId);
	public Login getLoginDetailsById(String userId);
	public User deleteUserDetailsById(String userId);
	public Login deleteLoginDetailsById(String Id);
	public Login changePassword(Login login);
	public Login resetPassword(Login login);
	public User updateUserDetails(User user) throws InvalidUserException;
	public User getUserDetailsByemail(String email);
	
	

}
