package com.May10.pack4.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.May10.pack4.model.Program;

public interface IProgramRepository extends JpaRepository<Program, Integer>{
	
	@Query(value="select * from program_table where program_name=?1",nativeQuery=true)
	public List<Program> getProgramDetailsByName(String programName);
	@Query(value="select * from program_table where eligibility=?1",nativeQuery=true)
	public List<Program> getProgramDetailsByEligibility(String eligibility);
	@Transactional
	@Modifying
	@Query(value="delete from program_table p where p.programid=?1",nativeQuery=true)
	public int deleteProgramById(int programid);
	@Transactional
	@Modifying
	@Query(value="delete from program_table p where p.program_name=?1",nativeQuery=true)
	public int deleteProgamByName(String programName); 
	@Query(value="select * from program_table where programid=?1",nativeQuery=true)
	public int getProgramById(int programid);
	@Transactional
	@Modifying
	@Query(value="update Program p set p.programName=?1 where p.programid=?2")
	public int updateProgramStatus(String programName,int programid );
}
