package com.May10.pack4.model;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.OneToOne;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.Id;
@Entity
@Table(name="Application_Table")
public class Application {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private int applicationId;
private String applicantFullName;
/*@JsonFormat(pattern="dd/MM/yyyy")
@Temporal(TemporalType.DATE)
@DateTimeFormat(pattern="dd/MM/yyyy")*/
private Date dateOfBirth;
private String highestQualification;
private double finalYearPercentage;
private String goals;
private String emailId;
@OneToOne(cascade=CascadeType.ALL)
private ProgramScheduleId schedule;
private String applicationStatus;
/*@JsonFormat(pattern="dd/MM/yyyy")
@Temporal(TemporalType.DATE)
@DateTimeFormat(pattern="dd/MM/yyyy")*/
private Date dateOfInterview;
private String applicantInterviewFeedback;
public int getApplicationId() {
	return applicationId;
}
public void setApplicationId(int applicationId) {
	this.applicationId = applicationId;
}
public String getApplicantFullName() {
	return applicantFullName;
}
public void setApplicantFullName(String applicantFullName) {
	this.applicantFullName = applicantFullName;
}
public Date getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(Date dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getHighestQualification() {
	return highestQualification;
}
public void setHighestQualification(String highestQualification) {
	this.highestQualification = highestQualification;
}
public double getFinalYearPercentage() {
	return finalYearPercentage;
}
public void setFinalYearPercentage(double finalYearPercentage) {
	this.finalYearPercentage = finalYearPercentage;
}
public String getGoals() {
	return goals;
}
public void setGoals(String goals) {
	this.goals = goals;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public ProgramScheduleId getSchedule() {
	return schedule;
}
public void setSchedule(ProgramScheduleId schedule) {
	this.schedule = schedule;
}
public String getApplicationStatus() {
	return applicationStatus;
}
public void setApplicationStatus(String applicationStatus) {
	this.applicationStatus = applicationStatus;
}
public Date getDateOfInterview() {
	return dateOfInterview;
}
public void setDateOfInterview(Date dateOfInterview) {
	this.dateOfInterview = dateOfInterview;
}
public String getApplicantInterviewFeedback() {
	return applicantInterviewFeedback;
}
public void setApplicantInterviewFeedback(String applicantInterviewFeedback) {
	this.applicantInterviewFeedback = applicantInterviewFeedback;
}



}
