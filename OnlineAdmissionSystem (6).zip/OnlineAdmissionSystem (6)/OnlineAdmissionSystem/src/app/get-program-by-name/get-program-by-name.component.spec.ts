import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetProgramByNameComponent } from './get-program-by-name.component';

describe('GetProgramByNameComponent', () => {
  let component: GetProgramByNameComponent;
  let fixture: ComponentFixture<GetProgramByNameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetProgramByNameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetProgramByNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
