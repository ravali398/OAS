import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Program } from '../model/program';
import { ProgramServiceService } from '../service/program-service.service';

@Component({
  selector: 'app-get-program-by-name',
  templateUrl: './get-program-by-name.component.html',
  styleUrls: ['./get-program-by-name.component.css']
})
export class GetProgramByNameComponent implements OnInit {

  programName:String;
  msg:String="";
programs:Program[]=[];

  constructor(private bs:ProgramServiceService,private router:Router) { 

  }

  ngOnInit() {
  }
  public name(){
    console.log(this.programName);
    this.bs.extractByName(this.programName).subscribe(response=>{
      this.programs=response;
      console.log(response);
        alert(this.programName);
      
    })
  }
}

