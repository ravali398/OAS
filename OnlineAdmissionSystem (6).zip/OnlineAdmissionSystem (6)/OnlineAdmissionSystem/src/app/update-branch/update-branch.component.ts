import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Branch } from '../model/branch';
import { BranchServiceService } from '../service/branch-service.service';

@Component({
  selector: 'app-update-branch',
  templateUrl: './update-branch.component.html',
  styleUrls: ['./update-branch.component.css']
})
export class UpdateBranchComponent implements OnInit {
  branch:Branch;
  branchId:number;
  bDescription:String;
  constructor(private r:ActivatedRoute,private bs:BranchServiceService,private router:Router) { }

  ngOnInit() {
    this.branchId=this.r.snapshot.params['p'];
    this.bs.extractById(this.branchId).subscribe(response=>
 {
  this.branch=response;
  this.bDescription=this.branch.branchDescription;
  
  
 })
}

public BranchUpdation(){
  this.branch.branchDescription=this.bDescription;
  
    this.bs.updateById(this.branch,this.branch.branchId).subscribe(response=>{
      console.log(response);
      alert("branch is updated");
      this.router.navigate(['ViewBranch']);
    })
   }
  
   
    }
  


