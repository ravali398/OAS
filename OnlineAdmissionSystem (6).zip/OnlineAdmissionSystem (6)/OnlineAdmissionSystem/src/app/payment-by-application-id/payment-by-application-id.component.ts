import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Payment } from '../model/payment';
import { PaymentServiceService } from '../service/payment-service.service';

@Component({
  selector: 'app-payment-by-application-id',
  templateUrl: './payment-by-application-id.component.html',
  styleUrls: ['./payment-by-application-id.component.css']
})
export class PaymentByApplicationIdComponent implements OnInit {
  applicationId:number;
  msg:String="";
  payment:Payment;
  errormsg:String="";
  errorMsg:String="";

  constructor(private paymentService:PaymentServiceService,private router:Router) { 

  }

  ngOnInit() {
  }
  public PaymentByApplicationId(){
    console.log(this.applicationId);
    this.paymentService.extractByApplicationId(this.applicationId).subscribe(response=>{
      this.payment=response;
      this.errorMsg=(response.errorMsg);
      console.log(response.errorMsg);
            
    })
  }
}

