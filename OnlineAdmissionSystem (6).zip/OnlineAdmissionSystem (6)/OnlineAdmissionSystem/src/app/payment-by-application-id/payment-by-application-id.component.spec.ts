import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentByApplicationIdComponent } from './payment-by-application-id.component';

describe('PaymentByApplicationIdComponent', () => {
  let component: PaymentByApplicationIdComponent;
  let fixture: ComponentFixture<PaymentByApplicationIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentByApplicationIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentByApplicationIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
