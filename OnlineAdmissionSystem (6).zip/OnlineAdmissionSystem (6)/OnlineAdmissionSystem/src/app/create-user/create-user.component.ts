import { Component, OnInit } from '@angular/core';
import { Login } from '../model/login';
import { User } from '../model/user';
import { UserServiceService } from '../service/user-service.service';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {
  UserObj:User=new User();
  firstName:String="";
	middleName:String="";
	lastName:String="";
  email:String="";
  mobileNumber:String="";
   aadharcardNo:String="";
  constructor(private userService:UserServiceService) { }

  ngOnInit() {
  }
  public createUser():void{
    console.log(this.UserObj.userId+""+this.UserObj.login.loginId);
    console.log(this.UserObj);
    this.userService.addUser(this.UserObj).subscribe(
      (data)=>
      {
          console.log(data);
      alert("User Added");
    }
    )
  }


}
