import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetcollegedetailsbybranchnameComponent } from './getcollegedetailsbybranchname.component';

describe('GetcollegedetailsbybranchnameComponent', () => {
  let component: GetcollegedetailsbybranchnameComponent;
  let fixture: ComponentFixture<GetcollegedetailsbybranchnameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetcollegedetailsbybranchnameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetcollegedetailsbybranchnameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
