import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { College } from '../model/college';
import { CollegeServiceService } from '../service/college-service.service';

@Component({
  selector: 'app-getcollegedetailsbybranchname',
  templateUrl: './getcollegedetailsbybranchname.component.html',
  styleUrls: ['./getcollegedetailsbybranchname.component.css']
})
export class GetcollegedetailsbybranchnameComponent implements OnInit {

  branchName:String="";
msg:String="";
college:College[]=[];

  constructor(private bs:CollegeServiceService,private router:Router) { 

  }

  
  ngOnInit() {
  }
  public CollegeByBranchName(){
    console.log(this.branchName);
    this.bs.extractBybranchname(this.branchName).subscribe(response=>{
      this.college=response;
      console.log(response);
        alert(this.branchName);
      
    })
  }
}