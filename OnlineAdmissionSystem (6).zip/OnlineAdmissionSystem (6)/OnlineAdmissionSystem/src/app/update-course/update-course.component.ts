import { Component, OnInit } from '@angular/core';
import { Course } from '../model/course';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentServiceService } from '../service/payment-service.service';
import { CourseServiceService } from '../service/course-service.service';

@Component({
  selector: 'app-update-course',
  templateUrl: './update-course.component.html',
  styleUrls: ['./update-course.component.css']
})
export class UpdateCourseComponent implements OnInit {
course:Course=new Course();
courseId:number;
celigiblity:String;

  constructor(private r:ActivatedRoute,private cs:CourseServiceService,private router:Router) { }

  ngOnInit() {
    this.courseId=this.r.snapshot.params['p'];
    this.cs.extractById(this.courseId).subscribe(response=>
     {
  this.course=response;
  this.celigiblity=this.course.eligiblity;
 
 })
  }
  public updateCourse(){
    this.course.eligiblity=this.celigiblity;
  this.cs.updateById(this.course,this.course.courseId).subscribe(response=>{
        console.log(response);
        this.router.navigate(['viewcoursebyadmin']);
      
        
    })
  
  }

}
