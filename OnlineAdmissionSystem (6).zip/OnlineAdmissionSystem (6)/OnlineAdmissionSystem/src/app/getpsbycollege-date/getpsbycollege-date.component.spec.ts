import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetpsbycollegeDateComponent } from './getpsbycollege-date.component';

describe('GetpsbycollegeDateComponent', () => {
  let component: GetpsbycollegeDateComponent;
  let fixture: ComponentFixture<GetpsbycollegeDateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetpsbycollegeDateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetpsbycollegeDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
