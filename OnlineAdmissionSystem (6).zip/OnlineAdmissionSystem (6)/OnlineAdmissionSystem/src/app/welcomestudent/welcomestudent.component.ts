import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoginServiceService } from '../service/login-service.service';


@Component({
  selector: 'app-welcomestudent',
  templateUrl: './welcomestudent.component.html',
  styleUrls: ['./welcomestudent.component.css']
})
export class WelcomestudentComponent implements OnInit {

  
  name:string="";
  msg:string="";
  adminFlag:boolean;
  studentFlag:boolean;
  constructor(private route:ActivatedRoute,private loginService:LoginServiceService) {

   }

  ngOnInit() {
    this.name=this.route.snapshot.params['p']
       this.studentFlag=this.loginService.isStudent();
     }
  /*public addProduct():void{
    console.log(this.product);
    this.ps.addProduct(this.product).subscribe((p)=>
    {
      this.msg=p;
      console.log(this.msg);
      alert("product has been added");
    }
  );

}*/
}