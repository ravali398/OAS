import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Branch } from '../model/branch';
import { BranchServiceService } from '../service/branch-service.service';

@Component({
  selector: 'app-get-branch-by-id',
  templateUrl: './get-branch-by-id.component.html',
  styleUrls: ['./get-branch-by-id.component.css']
})
export class GetBranchByIdComponent implements OnInit {

  branchId:number;
  msg:String="";
  branch:Branch;

  constructor(private bs:BranchServiceService,private router:Router) { 

  }

  ngOnInit() {
  }
  public BranchId(){
    console.log(this.branchId);
    this.bs.extractById(this.branchId).subscribe(response=>{
      this.branch=response;
      console.log(response);
        alert(this.branchId);
      
    })
  }
}

