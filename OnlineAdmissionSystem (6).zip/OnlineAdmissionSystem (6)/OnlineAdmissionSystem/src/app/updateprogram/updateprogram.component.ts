import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ActionSequence } from 'protractor';
import { Program } from '../model/program';
import { ProgramServiceService } from '../service/program-service.service';

@Component({
  selector: 'app-updateprogram',
  templateUrl: './updateprogram.component.html',
  styleUrls: ['./updateprogram.component.css']
})
export class UpdateprogramComponent implements OnInit {
  programid:number;
  Name:String;
  program:Program;
  constructor(private r:ActivatedRoute,private ps:ProgramServiceService,private router:Router) { }

  ngOnInit() {
    this.programid=this.r.snapshot.params['p'];
    console.log(this.programid)
    this.ps.extractById(this.programid).subscribe(response=>{
      this.program=response;
      this.Name=this.program.programName;
      console.log(this.Name)

    })
}
 public updateProgram(){
  this.program.programName=this.Name;
  this.ps.updateById(this.program,this.program.programid).subscribe(response=>{
    console.log(response);
    alert("Program is updated");
    this.router.navigate(['ViewProgram']);
  })
 
  }

}

