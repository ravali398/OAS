import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from '../model/login';
import { UserServiceService } from '../service/user-service.service';

@Component({
  selector: 'app-view-login',
  templateUrl: './view-login.component.html',
  styleUrls: ['./view-login.component.css']
})
export class ViewLoginComponent implements OnInit {

  msg:String="";
  logindetails:Login[]=[];
    constructor(private userservice:UserServiceService,private router:Router) { }
  
    ngOnInit() {
      this.userservice.extractLogin().subscribe(response=>{this.logindetails=response;})
       
        }
        public deleteLoginDetailsById(Id:String){
          console.log(Id);
          this.userservice.deleteLoginDetailsById(Id).subscribe(response=>{
            console.log(response);
            this.msg=`${Id}`+" "+"is deleted";
            alert("Login details are deleted");
            window.location.reload();
          })
        }
        public EditLoginDetails(Id:String){
          console.log(Id);
          this.router.navigate(['UpdateLogin',Id]);
        }
  

}
