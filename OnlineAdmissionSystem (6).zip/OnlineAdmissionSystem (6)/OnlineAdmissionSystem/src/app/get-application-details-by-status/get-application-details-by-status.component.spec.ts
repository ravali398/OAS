import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetApplicationDetailsByStatusComponent } from './get-application-details-by-status.component';

describe('GetApplicationDetailsByStatusComponent', () => {
  let component: GetApplicationDetailsByStatusComponent;
  let fixture: ComponentFixture<GetApplicationDetailsByStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetApplicationDetailsByStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetApplicationDetailsByStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
