import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Application } from '../model/application';
import { ApplicationServiceService } from '../service/application-service.service';

@Component({
  selector: 'app-get-application-details-by-status',
  templateUrl: './get-application-details-by-status.component.html',
  styleUrls: ['./get-application-details-by-status.component.css']
})
export class GetApplicationDetailsByStatusComponent implements OnInit {

  bStatus:String;
  msg:String="";
  applications:Application[]=[];

  constructor(private bs:ApplicationServiceService,private router:Router) { 

  }

  ngOnInit() {
  }

  public Status(){
    console.log(this.bStatus);
    this.bs.extractByStatus(this.bStatus).subscribe(response=>{
      this.applications=response;
      console.log(response);
        alert(this.bStatus);
      
  
  })

}
}