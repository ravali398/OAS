import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from '../model/course';
import { CourseServiceService } from '../service/course-service.service';

@Component({
  selector: 'app-viewcoursedetailsbyadmin',
  templateUrl: './viewcoursedetailsbyadmin.component.html',
  styleUrls: ['./viewcoursedetailsbyadmin.component.css']
})
export class ViewcoursedetailsbyadminComponent implements OnInit {

  msg:String="";
  courses:Course[]=[];
    constructor(private cs:CourseServiceService,private router:Router) { }
  ngOnInit() {
    this.cs.extractCourse().subscribe(response=>{ this.courses=response;})}

    public deleteCourse(Id:number){
      console.log(Id);
      this.cs.deleteCourse(Id).subscribe(response=>{
        console.log(response);
        this.msg=`${Id}`+" "+"is deleted";
        alert("Course Id is deleted");
        window.location.reload();
      })
    }

    public EditCourse(courseId:number){
      console.log(courseId);
      this.router.navigate(['UpdateCourse',courseId])
    }

 

}

