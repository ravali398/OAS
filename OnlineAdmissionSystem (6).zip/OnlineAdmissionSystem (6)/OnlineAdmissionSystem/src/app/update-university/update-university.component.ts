import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { University } from '../model/university';
import { UniversityserviceService } from '../service/universityservice.service';

@Component({
  selector: 'app-update-university',
  templateUrl: './update-university.component.html',
  styleUrls: ['./update-university.component.css']
})
export class UpdateUniversityComponent implements OnInit {

university:University;
universityId:number;
puniversityName:String="";
errormsg:String="";

  constructor(private r:ActivatedRoute,private us:UniversityserviceService,private router:Router) { }

  ngOnInit() {
    this.universityId=this.r.snapshot.params['p'];
    this.us.extractById(this.universityId).subscribe(response=>
     {
  this.university=response;
  this.puniversityName=this.university.universityname;
 })
  }
  public UpdateUniversity(){
    this.university.universityname=this.puniversityName;
    this.us.updateById(this.university,this.university.universityId).subscribe(response=>{
        console.log(response);
        if(response!=null)
      alert("university is updated");
      this.router.navigate(['viewuniversitybyadmin']);
    })
   }
  
  

}

