import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { ErrorComponent } from './error/error.component';
import { LogoutComponent } from './logout/logout.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { HttpClientModule } from '@angular/common/http';
import { ViewUserComponent } from './view-user/view-user.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { ViewLoginComponent } from './view-login/view-login.component';
import { UpdateLoginComponent } from './update-login/update-login.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { CreatePaymentComponent } from './create-payment/create-payment.component';
import { MakePaymentComponent } from './make-payment/make-payment.component';
import { ViewPaymentComponent } from './view-payment/view-payment.component';
import { UpdatePaymentComponent } from './update-payment/update-payment.component';
import { PaymentByEmailComponent } from './payment-by-email/payment-by-email.component';
import { PaymentByStatusComponent } from './payment-by-status/payment-by-status.component';
import { PaymentByApplicationIdComponent } from './payment-by-application-id/payment-by-application-id.component';
import { PaymentByPaymentIdComponent } from './payment-by-payment-id/payment-by-payment-id.component';
import { CreateBranchComponentComponent } from './create-branch-component/create-branch-component.component';
import { ViewBranchComponent } from './view-branch/view-branch.component';
import { UpdateBranchComponent } from './update-branch/update-branch.component';
import { GetBranchByIdComponent } from './get-branch-by-id/get-branch-by-id.component';
import { GetBranchByNameComponent } from './get-branch-by-name/get-branch-by-name.component';
import { CreateAddressComponent } from './create-address/create-address.component';
import { ViewAddressComponent } from './view-address/view-address.component';
import { UpdateAddressComponent } from './update-address/update-address.component';
import { CreatecourseComponent } from './createcourse/createcourse.component';
import { CreateApplicationComponent } from './create-application/create-application.component';
import { CreateProgramComponent } from './create-program/create-program.component';
import { ViewprogramComponent } from './viewprogram/viewprogram.component';
import { UpdateprogramComponent } from './updateprogram/updateprogram.component';
import { GetProgramByIdComponent } from './get-program-by-id/get-program-by-id.component';
import { GetProgramByNameComponent } from './get-program-by-name/get-program-by-name.component';
import { GetProgramByEligibilityComponent } from './get-program-by-eligibility/get-program-by-eligibility.component';
import { ViewcourseComponent } from './viewcourse/viewcourse.component';
import { UpdateComponent } from './update/update.component';
import { UpdateCourseComponent } from './update-course/update-course.component';
import { GetDetailsbyEligiblityComponent } from './get-detailsby-eligiblity/get-detailsby-eligiblity.component';
import { GetDetailsByCourseNameComponent } from './get-details-by-course-name/get-details-by-course-name.component';
import { GetDetailsByCollegeNameComponent } from './get-details-by-college-name/get-details-by-college-name.component';
import { CreateuniversityComponent } from './createuniversity/createuniversity.component';
import { ViewUniversityComponent } from './view-university/view-university.component';
import { UpdateUniversityComponent } from './update-university/update-university.component';
import { GetuniversitybycityComponent } from './getuniversitybycity/getuniversitybycity.component';
import { GetuniversitybycollegenameComponent } from './getuniversitybycollegename/getuniversitybycollegename.component';
import { CreateprogramscheduleComponent } from './createprogramschedule/createprogramschedule.component';
import { ViewApplicationComponent } from './view-application/view-application.component';
import { ServiceComponent } from './service/service.component';
import { UpdateApplicationComponent } from './update-application/update-application.component';
import { GetApplicationDetailsByEmailComponent } from './get-application-details-by-email/get-application-details-by-email.component';
import { GetApplicationDetailsByStatusComponent } from './get-application-details-by-status/get-application-details-by-status.component';
import { CreateCollegeComponent } from './create-college/create-college.component';
import { ViewCollegeComponent } from './view-college/view-college.component';
import { UpdateCollegeComponent } from './update-college/update-college.component';
import { GetcollegedetailsbycollegenameComponent } from './getcollegedetailsbycollegename/getcollegedetailsbycollegename.component';
import { GetcollegedetailsbyprogramnameComponent } from './getcollegedetailsbyprogramname/getcollegedetailsbyprogramname.component';
import { GetcollegedetailsbycoursenameComponent } from './getcollegedetailsbycoursename/getcollegedetailsbycoursename.component';
import { GetcollegedetailsbybranchnameComponent } from './getcollegedetailsbybranchname/getcollegedetailsbybranchname.component';
import { CreateComponent } from './create/create.component';
import { ViewprogramscheduleIdComponent } from './viewprogramschedule-id/viewprogramschedule-id.component';
import { UpdateprogramScheduleComponent } from './updateprogram-schedule/updateprogram-schedule.component';
import { GetpsbycollegenameComponent } from './getpsbycollegename/getpsbycollegename.component';
import { GetpsbycollegeDateComponent } from './getpsbycollege-date/getpsbycollege-date.component';
import { GetpsbyDateComponent } from './getpsby-date/getpsby-date.component';
import { WelcomestudentComponent } from './welcomestudent/welcomestudent.component';
import { ContactComponent } from './contact/contact.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { HomeComponent } from './home/home.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { CreateNewPasswordComponent } from './create-new-password/create-new-password.component';
import { GetcoursebyIdComponent } from './getcourseby-id/getcourseby-id.component';
import { GetuniversitybyIdComponent } from './getuniversityby-id/getuniversityby-id.component';
import { ViewcoursedetailsbyadminComponent } from './viewcoursedetailsbyadmin/viewcoursedetailsbyadmin.component';
import { ViewuniversitybyadminComponent } from './viewuniversitybyadmin/viewuniversitybyadmin.component';
;

@NgModule({
  declarations: [
    AppComponent,
    CreateUserComponent,
    LoginComponent,
    ErrorComponent,
    LogoutComponent,
    WelcomeComponent,
    ViewUserComponent,
    UpdateUserComponent,
    ViewLoginComponent,
    UpdateLoginComponent,
    ResetPasswordComponent,
    CreatePaymentComponent,
    MakePaymentComponent,
    ViewPaymentComponent,
    UpdatePaymentComponent,
    PaymentByEmailComponent,
    PaymentByStatusComponent,
    PaymentByApplicationIdComponent,
    PaymentByPaymentIdComponent,
    CreateBranchComponentComponent,
    ViewBranchComponent,
    UpdateBranchComponent,
    GetBranchByIdComponent,
    GetBranchByNameComponent,
    CreateAddressComponent,
    ViewAddressComponent,
    UpdateAddressComponent,
    CreatecourseComponent,
    CreateApplicationComponent,
    CreateProgramComponent,
    ViewprogramComponent,
    UpdateprogramComponent,
    GetProgramByIdComponent,
    GetProgramByNameComponent,
    GetProgramByEligibilityComponent,
    ViewcourseComponent,
    UpdateComponent,
    UpdateCourseComponent,
    GetDetailsbyEligiblityComponent,
    GetDetailsByCourseNameComponent,
    GetDetailsByCollegeNameComponent,
    CreateuniversityComponent,
    ViewUniversityComponent,
    UpdateUniversityComponent,
    GetuniversitybycityComponent,
    GetuniversitybycollegenameComponent,
    CreateprogramscheduleComponent,
    ViewApplicationComponent,
    ServiceComponent,
    UpdateApplicationComponent,
    GetApplicationDetailsByEmailComponent,
    GetApplicationDetailsByStatusComponent,
    CreateCollegeComponent,
    ViewCollegeComponent,
    UpdateCollegeComponent,
    GetcollegedetailsbycollegenameComponent,
    GetcollegedetailsbyprogramnameComponent,
    GetcollegedetailsbycoursenameComponent,
    GetcollegedetailsbybranchnameComponent,
    CreateComponent,
    ViewprogramscheduleIdComponent,
    UpdateprogramScheduleComponent,
    GetpsbycollegenameComponent,
    GetpsbycollegeDateComponent,
    GetpsbyDateComponent,
    WelcomestudentComponent,
    ContactComponent,
    AboutusComponent,
    HomeComponent,
    ForgotPasswordComponent,
    CreateNewPasswordComponent,
    GetcoursebyIdComponent,
    GetuniversitybyIdComponent,
    ViewcoursedetailsbyadminComponent,
    ViewuniversitybyadminComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
