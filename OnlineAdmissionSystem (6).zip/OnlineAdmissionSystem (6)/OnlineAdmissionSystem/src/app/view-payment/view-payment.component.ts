import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Payment } from '../model/payment';
import { PaymentServiceService } from '../service/payment-service.service';

@Component({
  selector: 'app-view-payment',
  templateUrl: './view-payment.component.html',
  styleUrls: ['./view-payment.component.css']
})
export class ViewPaymentComponent implements OnInit {

  msg:String="";
payments:Payment[]=[];
  constructor(private paymentService:PaymentServiceService,private router:Router) { }

  ngOnInit() {
    this.paymentService.extractPayment().subscribe(response=>{ this.payments=response;})}

    public deletePayment(paymentId:number){
      console.log(paymentId);
      this.paymentService.deletePayment(paymentId).subscribe(response=>{
        console.log(response);
        this.msg=`${paymentId}`+" "+"is deleted";
        alert("payment Id is deleted");
        window.location.reload();
      }) 

}
public EditPayment(paymentId:number){
  console.log(paymentId);
  this.router.navigate(['UpdatePayment',paymentId])
}
}


