import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateBranchComponentComponent } from './create-branch-component.component';

describe('CreateBranchComponentComponent', () => {
  let component: CreateBranchComponentComponent;
  let fixture: ComponentFixture<CreateBranchComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateBranchComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateBranchComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
