import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { University } from '../model/university';
import { UniversityserviceService } from '../service/universityservice.service';

@Component({
  selector: 'app-viewuniversitybyadmin',
  templateUrl: './viewuniversitybyadmin.component.html',
  styleUrls: ['./viewuniversitybyadmin.component.css']
})
export class ViewuniversitybyadminComponent implements OnInit {

  msg:String="";
  university:University[]=[];
  universityId:number;
    constructor(private us:UniversityserviceService,private router:Router) { }
  
    ngOnInit() {
      this.us.extractUniversity().subscribe(response=>{ this.university=response;})}
  
      public deleteUniversity(universityId:number){
        console.log(universityId);
        this.us.deleteUniversity(universityId).subscribe(response=>{
          console.log(response);
          this.msg=`${universityId}`+" "+"is deleted";
          alert("university Id is deleted");
          window.location.reload();
        }) 
  
  }
  public EditUniveristy(universityId:number){
    console.log(universityId);
    this.router.navigate(['Up',universityId])
  }
  }
  
  