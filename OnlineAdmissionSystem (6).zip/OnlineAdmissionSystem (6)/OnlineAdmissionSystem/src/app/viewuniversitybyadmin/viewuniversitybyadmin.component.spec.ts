import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewuniversitybyadminComponent } from './viewuniversitybyadmin.component';

describe('ViewuniversitybyadminComponent', () => {
  let component: ViewuniversitybyadminComponent;
  let fixture: ComponentFixture<ViewuniversitybyadminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewuniversitybyadminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewuniversitybyadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
