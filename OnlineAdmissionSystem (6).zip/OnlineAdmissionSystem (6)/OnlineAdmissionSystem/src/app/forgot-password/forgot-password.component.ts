import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmailServiceService } from '../service/email-service.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  Email:String;
  msg:String="";

  constructor(private bs:EmailServiceService,private router:Router) { 

  }

  ngOnInit() {
  }

  public OTP(){
    console.log(this.Email);
    this.bs.sendMail(this.Email).subscribe(response=>{
      this.msg=response;
      console.log(response);
       if(response!=null){
        alert("OTP send successfully")
        
       }
       else
{
  alert("Invalid email Id")
}    
  
  })
}

}
