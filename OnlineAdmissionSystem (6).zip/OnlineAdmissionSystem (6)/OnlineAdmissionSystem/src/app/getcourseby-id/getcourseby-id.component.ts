import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from '../model/course';
import { CourseServiceService } from '../service/course-service.service';

@Component({
  selector: 'app-getcourseby-id',
  templateUrl: './getcourseby-id.component.html',
  styleUrls: ['./getcourseby-id.component.css']
})
export class GetcoursebyIdComponent implements OnInit {
  courseId:number;
  msg:String="";
  errorMsg:String="";
  course:Course;
  constructor(private bs:CourseServiceService,private router:Router) { 

  }

  ngOnInit() {
  }

  public CourseId(){
    console.log(this.courseId);
    this.bs.extractById(this.courseId).subscribe(response=>{
      this.course=response; 
      console.log(response);
      this.errorMsg=(response.errorMsg);
      console.log(response.errorMsg);
            
        
    
    })
  }

}

