import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetcoursebyIdComponent } from './getcourseby-id.component';

describe('GetcoursebyIdComponent', () => {
  let component: GetcoursebyIdComponent;
  let fixture: ComponentFixture<GetcoursebyIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetcoursebyIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetcoursebyIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
