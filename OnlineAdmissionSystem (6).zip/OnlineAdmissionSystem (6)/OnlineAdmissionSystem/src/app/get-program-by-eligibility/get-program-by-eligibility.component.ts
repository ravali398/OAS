import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Program } from '../model/program';
import { ProgramServiceService } from '../service/program-service.service';

@Component({
  selector: 'app-get-program-by-eligibility',
  templateUrl: './get-program-by-eligibility.component.html',
  styleUrls: ['./get-program-by-eligibility.component.css']
})
export class GetProgramByEligibilityComponent implements OnInit {

  eligibility:String;
  msg:String="";
programs:Program[]=[];

  constructor(private bs:ProgramServiceService,private router:Router) { 

  }

  ngOnInit() {
  }
  public Programeligibility(){
    console.log(this.eligibility);
    this.bs.extractByEligibility(this.eligibility).subscribe(response=>{
      this.programs=response;
      console.log(response);
        alert(this.eligibility);
      
    })
  }
}

