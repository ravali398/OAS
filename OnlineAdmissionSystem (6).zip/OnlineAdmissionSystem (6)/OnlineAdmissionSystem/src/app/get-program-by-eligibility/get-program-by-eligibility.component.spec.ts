import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetProgramByEligibilityComponent } from './get-program-by-eligibility.component';

describe('GetProgramByEligibilityComponent', () => {
  let component: GetProgramByEligibilityComponent;
  let fixture: ComponentFixture<GetProgramByEligibilityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetProgramByEligibilityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetProgramByEligibilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
