import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PaymentServiceService } from '../service/payment-service.service';
import { Payment } from '../model/payment';

@Component({
  selector: 'app-payment-by-email',
  templateUrl: './payment-by-email.component.html',
  styleUrls: ['./payment-by-email.component.css']
})
export class PaymentByEmailComponent implements OnInit {
emailId:String;
msg:String="";
payment:Payment[]=[];
  constructor(private paymentService:PaymentServiceService,private router:Router) { 

  }

  ngOnInit() {
  }
  public PaymentByEmail(){
    console.log(this.emailId);
    this.paymentService.extractByEmail(this.emailId).subscribe(response=>{
      this.payment=response;
      if((this.emailId)==("this.payment.emailId"))
      {
      console.log(response);
        alert("emailId does not exist");
      }
      else {
        alert("payment details are shown");
      }
    })
  }
}
