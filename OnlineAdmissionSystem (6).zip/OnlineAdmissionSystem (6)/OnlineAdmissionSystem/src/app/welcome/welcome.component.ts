import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LoginComponent } from '../login/login.component';
import { LoginServiceService } from '../service/login-service.service';
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
/*customers=[new Customer(100,"xyz",87654,"abc@gmail.com"),
         new Customer(12,"abc",97654,"ss@gmail.com"),
         new Customer(10,"pqr",89654,"cbc@gmail.com"),
         new Customer(1000,"xz",8654,"ac@gmail.com")];*/
  name:string="";
  msg:string="";
  adminFlag:boolean;
 
  constructor(private route:ActivatedRoute,private loginService:LoginServiceService) {

   }

  ngOnInit() {
    this.name=this.route.snapshot.params['id']
    this.adminFlag=this.loginService.isAdmin();
    
     }
  /*public addProduct():void{
    console.log(this.product);
    this.ps.addProduct(this.product).subscribe((p)=>
    {
      this.msg=p;
      console.log(this.msg);
      alert("product has been added");
    }
  );

}*/
}