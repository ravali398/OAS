import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from '../model/course';
import { CourseServiceService } from '../service/course-service.service';

@Component({
  selector: 'app-get-details-by-course-name',
  templateUrl: './get-details-by-course-name.component.html',
  styleUrls: ['./get-details-by-course-name.component.css']
})
export class GetDetailsByCourseNameComponent implements OnInit {
  courseName:String;
  msg:String="";
  c:Course[]=[];


  constructor(private bs:CourseServiceService,private router:Router) { 

  }

  ngOnInit() {
  }

  public CourseName(){
    console.log(this.courseName);
    this.bs.extractByCourseName(this.courseName).subscribe(response=>{
      this.c=response; 
      console.log(response);
        alert(this.courseName);
    
    })
  }

}
