import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetDetailsByCourseNameComponent } from './get-details-by-course-name.component';

describe('GetDetailsByCourseNameComponent', () => {
  let component: GetDetailsByCourseNameComponent;
  let fixture: ComponentFixture<GetDetailsByCourseNameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetDetailsByCourseNameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetDetailsByCourseNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
