import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetApplicationDetailsByEmailComponent } from './get-application-details-by-email.component';

describe('GetApplicationDetailsByEmailComponent', () => {
  let component: GetApplicationDetailsByEmailComponent;
  let fixture: ComponentFixture<GetApplicationDetailsByEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetApplicationDetailsByEmailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetApplicationDetailsByEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
