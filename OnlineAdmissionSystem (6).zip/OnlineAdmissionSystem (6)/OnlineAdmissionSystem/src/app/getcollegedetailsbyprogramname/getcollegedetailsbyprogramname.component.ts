import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { College } from '../model/college';
import { CollegeServiceService } from '../service/college-service.service';

@Component({
  selector: 'app-getcollegedetailsbyprogramname',
  templateUrl: './getcollegedetailsbyprogramname.component.html',
  styleUrls: ['./getcollegedetailsbyprogramname.component.css']
})
export class GetcollegedetailsbyprogramnameComponent implements OnInit {

  Name:String="";
  msg:String="";
  col:College[]=[];
  
    constructor(private bs:CollegeServiceService,private router:Router) { 
      }
  
    
    ngOnInit() {
    }
    public CollegeByprogramName(){
      console.log(this.Name);
      this.bs.extractByprogramname(this.Name).subscribe(response=>{
        this.col=response;
        console.log(response);
          alert(this.Name);
        
      })
    }
}
