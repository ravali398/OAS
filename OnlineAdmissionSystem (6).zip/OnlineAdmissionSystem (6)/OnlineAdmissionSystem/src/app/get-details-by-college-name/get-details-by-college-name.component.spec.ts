import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetDetailsByCollegeNameComponent } from './get-details-by-college-name.component';

describe('GetDetailsByCollegeNameComponent', () => {
  let component: GetDetailsByCollegeNameComponent;
  let fixture: ComponentFixture<GetDetailsByCollegeNameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetDetailsByCollegeNameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetDetailsByCollegeNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
