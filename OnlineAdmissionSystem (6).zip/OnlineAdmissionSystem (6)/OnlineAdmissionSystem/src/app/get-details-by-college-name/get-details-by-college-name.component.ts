import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from '../model/course';
import { CourseServiceService } from '../service/course-service.service';

@Component({
  selector: 'app-get-details-by-college-name',
  templateUrl: './get-details-by-college-name.component.html',
  styleUrls: ['./get-details-by-college-name.component.css']
})
export class GetDetailsByCollegeNameComponent implements OnInit {

  collegeName:String;
  msg:String="";
  c:Course[]=[];

  constructor(private bs:CourseServiceService,private router:Router) { 

  }

  ngOnInit() {
  }

  public CollegeName(){
    console.log(this.collegeName);
    this.bs.extractByCollegeName(this.collegeName).subscribe(response=>{
      this.c=response;
      console.log(response);
        alert(this.collegeName);
      
    })
  }

}
