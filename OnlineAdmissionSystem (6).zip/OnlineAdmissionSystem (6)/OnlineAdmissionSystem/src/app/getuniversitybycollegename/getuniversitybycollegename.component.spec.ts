import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetuniversitybycollegenameComponent } from './getuniversitybycollegename.component';

describe('GetuniversitybycollegenameComponent', () => {
  let component: GetuniversitybycollegenameComponent;
  let fixture: ComponentFixture<GetuniversitybycollegenameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetuniversitybycollegenameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetuniversitybycollegenameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
