import { Component, OnInit } from '@angular/core';
import { Address } from '../model/address';
import { AddressServiceService } from '../service/address-service.service';

@Component({
  selector: 'app-create-address',
  templateUrl: './create-address.component.html',
  styleUrls: ['./create-address.component.css']
})
export class CreateAddressComponent implements OnInit {
  addressObj:Address=new Address();
  msg:String="";
    constructor(private ps:AddressServiceService) { }
  
    ngOnInit() {
    }
    public createAddress():void{
      console.log(this.addressObj);
      this.ps.addAddress(this.addressObj).subscribe((p)=>
      {
        this.msg=p;
        console.log(this.msg);
        alert("address has been made");
        window.location.reload();
      }
    );
    
  
  }
  

}
