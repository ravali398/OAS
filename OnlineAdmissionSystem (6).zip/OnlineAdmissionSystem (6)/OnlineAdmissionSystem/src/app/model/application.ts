import { ProgramScheduleId } from "./program-schedule-id";

export class Application {
    public applicationId:number;
    public applicantFullName:String;
    public dateOfBirth:Date;
    public highestQualification:String;
    public finalYearPercentage:number;
    public goals:String;
    public emailId:String;
    public schedule: ProgramScheduleId=new ProgramScheduleId();
    public applicationStatus:String;
    public dateOfInterview:Date;
    public applicantInterviewFeedback:String;
}
