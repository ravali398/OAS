export class Payment {
    public paymentId:number;
    public emailId:String;
    public applicationId:number;
    public paymentAmount:number;
    public paymentDescription:String;
    public paymentDate:Date;
    public paymentStatus:String;
}
