export class Branch {
    public  branchId:number;
    public  branchName:String;
public  branchDescription:String;
}
