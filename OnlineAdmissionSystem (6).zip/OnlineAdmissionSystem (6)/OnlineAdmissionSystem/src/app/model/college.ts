import { Address } from "./address";
import { Branch } from "./branch";
import { Course } from "./course";
import { Program } from "./program";
import { University } from "./university";

export class College {
    public collegeId:number;
    public collegeName:String;
    public address:Address=new Address();
    public programList:Program[]=[];
    public courseList:Course[]=[];
    public branchList:Branch[]=[];
    public university:University=new University();
}
