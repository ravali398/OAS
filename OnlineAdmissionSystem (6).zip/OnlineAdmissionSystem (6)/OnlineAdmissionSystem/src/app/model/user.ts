import { Login } from "./login";

export class User {
    public  userId:String;
    public firstName:String;
	public middleName:String;
	public lastName:String;
	public email:String;
	public mobileNumber:String;
	public aadharcardNo:String;
    public login:Login=new Login();
}

