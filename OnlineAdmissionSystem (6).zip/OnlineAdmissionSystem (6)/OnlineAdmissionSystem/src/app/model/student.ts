export class Student {
    public studId:String;
    public studName:String;
    public studPhone:number;
    public studEmail:String;
    public constructor(studId:String,studName:string,studPhone:number,studEmail:string){
        this.studId=studId;
        this.studName=studName;
        this.studPhone=studPhone;
        this.studEmail=studEmail;
    }
    }