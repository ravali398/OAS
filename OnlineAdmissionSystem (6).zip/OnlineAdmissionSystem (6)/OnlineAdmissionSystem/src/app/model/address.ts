export class Address {
public addressId : number;
public city:String;
public district:String;
public  state:String;
public  zipcode:String;
public  landmark:String;
public  country:String;
}
