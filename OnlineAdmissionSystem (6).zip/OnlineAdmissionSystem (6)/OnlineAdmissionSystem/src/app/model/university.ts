import { Address } from "./address";
import { College } from "./college";

export class University {
   public universityId:number;
   public  universityname:String;
   public  collegeList:College[]=[];
   public  address:Address=new Address();
}

