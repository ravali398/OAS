import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { University } from '../model/university';
import { UniversityserviceService } from '../service/universityservice.service';
import { UniversityServiceService } from '../university-service.service';

@Component({
  selector: 'app-getuniversityby-id',
  templateUrl: './getuniversityby-id.component.html',
  styleUrls: ['./getuniversityby-id.component.css']
})
export class GetuniversitybyIdComponent implements OnInit {

  universityId:number;
  msg:String="";
  errorMsg:String="";
  university:University;
  
    constructor(private bs:UniversityserviceService,private router:Router) { 
  
    }
  
    
    ngOnInit() {
    }
    public Id(){
      console.log(this.universityId);
      this.bs.extractById(this.universityId).subscribe(response=>{
        this.university=response;
        console.log(response);
        this.errorMsg=(response.errorMsg);
        console.log(response.errorMsg);
         
        
      })
    }
  }
