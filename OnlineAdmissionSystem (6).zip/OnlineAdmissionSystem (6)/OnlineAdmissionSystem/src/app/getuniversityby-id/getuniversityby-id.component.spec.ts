import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetuniversitybyIdComponent } from './getuniversityby-id.component';

describe('GetuniversitybyIdComponent', () => {
  let component: GetuniversitybyIdComponent;
  let fixture: ComponentFixture<GetuniversitybyIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetuniversitybyIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetuniversitybyIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
