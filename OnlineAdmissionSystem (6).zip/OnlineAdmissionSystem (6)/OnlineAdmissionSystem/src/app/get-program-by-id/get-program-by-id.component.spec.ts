import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetProgramByIdComponent } from './get-program-by-id.component';

describe('GetProgramByIdComponent', () => {
  let component: GetProgramByIdComponent;
  let fixture: ComponentFixture<GetProgramByIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetProgramByIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetProgramByIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
