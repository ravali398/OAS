import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Program } from '../model/program';
import { ProgramServiceService } from '../service/program-service.service';

@Component({
  selector: 'app-get-program-by-id',
  templateUrl: './get-program-by-id.component.html',
  styleUrls: ['./get-program-by-id.component.css']
})
export class GetProgramByIdComponent implements OnInit {

  programid:number;
  msg:String="";
program:Program;

  constructor(private bs:ProgramServiceService,private router:Router) { 

  }

  ngOnInit() {
  }
  public ProgramId(){
    console.log(this.programid);
    this.bs.extractById(this.programid).subscribe(response=>{
      this.program=response;
      console.log(response);
        alert(this.programid);
      
    })
  }
}

