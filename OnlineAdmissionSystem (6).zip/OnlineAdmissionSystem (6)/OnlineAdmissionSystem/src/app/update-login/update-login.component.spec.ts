import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateLoginComponent } from './update-login.component';

describe('UpdateLoginComponent', () => {
  let component: UpdateLoginComponent;
  let fixture: ComponentFixture<UpdateLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
