import { Injectable } from '@angular/core';
import { ProjectURL } from '../project-url';
import { HttpClient } from '@angular/common/http';
import { Application } from '../model/application';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApplicationServiceService {
  url:String=ProjectURL.getUrl();
  constructor(private http:HttpClient) { }
  public addApplication(application:Application):Observable<any>{
    return this.http.post<any>(this.url+"createApplication",application);
  }
  public extractApplication():Observable<any>{
    return this.http.get(this.url+"getAllApplicationDetails");
  }
  public deleteApplicationById(Id:number):Observable<any>{
    return this.http.delete(this.url+`deleteApplicationById/${Id}`);
  }

  public extractById(Id:number):Observable<any>{
    return this.http.get(this.url+`getApplicationById/${Id}`);
    
  }
  public updateById(application:Application,applicationId:number):Observable<any>{
    return this.http.put<any>(this.url+`updateApplicationStatus/${applicationId}`,application);
  }
  public extractByEmail(email:String):Observable<any>{
    return this.http.get<any>(this.url+`getApplicationDetailsByEmail/${email}`);
  
  }
  public extractByStatus(status:String):Observable<any>{
    return this.http.get<any>(this.url+`getApplicationDetailsByStatus/${status}`);
  }
}


