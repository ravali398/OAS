import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ProjectURL } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class EmailServiceService {
  url:String=ProjectURL.getUrl();
  constructor(private http:HttpClient) { }
  public sendMail(mail:String):Observable<any>{
    return this.http.get<any>(this.url+`sendMail/${mail}`);
  }
}