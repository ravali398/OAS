import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { College } from '../model/college';
import { ProjectURL } from '../project-url';

@Injectable({
  providedIn: 'root'
})
export class CollegeServiceService {
  url:String=ProjectURL.getUrl();
  constructor(private http:HttpClient) { }
  public addCollege(college:College):Observable<any>{
    return this.http.post<any>(this.url+"createCollege",college);
  }
  public extractCollege():Observable<any>{
    return this.http.get(this.url+"getAllCollegeDetails");
  }

  public deleteCollege(Id:number):Observable<any>{
    return this.http.delete(this.url+`deleteCollegeById/${Id}`);
  }
  public extractById(Id:number):Observable<any>{
    return this.http.get(this.url+`getCollegeDetailsById/${Id}`);
    
  }
  public updateById(college:College,collegeId:number):Observable<any>{
    return this.http.put<any>(this.url+`UpdateCollege/${collegeId}`,college);
  }
  
  public extractBycollegename(collegeName:String):Observable<any>{
    return this.http.get<any>(this.url+`getCollegedeatilsByName/${collegeName}`);
  
  }
  public extractByprogramname(programName:String):Observable<any>{
    return this.http.get<any>(this.url+`getCollegedeatilsByProgramName/${programName}`);
  }
  public extractBybranchname(branchName:String):Observable<any>{
    return this.http.get<any>(this.url+`getCollegedeatilsByBranchName/${branchName}`);
  }
  public extractBycoursename(courseName:String):Observable<any>{
    return this.http.get<any>(this.url+`getCollegedeatilsByCourseName/${courseName}`);
  }


}


