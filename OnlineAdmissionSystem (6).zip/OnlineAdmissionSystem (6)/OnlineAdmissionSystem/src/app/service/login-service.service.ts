import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Login } from '../model/login';
import { User } from '../model/user';
import { ProjectURL } from '../project-url';
import { UserServiceService } from './user-service.service';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {
  url:string=ProjectURL.getUrl();
//put,get,post,delete
  
 login:Login;
  constructor(private userservice:UserServiceService,private http:HttpClient) { }
  public doLogin(Id:string):boolean{
   this.userservice.extractUser(Id).subscribe(response=>
    {
      console.log(response);
      this.login=response;
    });
    if(Id==this.login.loginId)
    {
      if(this.login.role=='student')
      {
        sessionStorage.setItem("studId",Id);
        return true;
      }
      else if(this.login.role=='admin')
      {
        sessionStorage.setItem("adminId",Id);
          return true;
      }
    } else{
        return false;
      }
    }
  
  public isAdmin():boolean{
    let adminId=sessionStorage.getItem('adminId');
    let adminPassword=sessionStorage.getItem('adminPassword');
    console.log(adminId+" "+adminPassword);
    return !(adminId==null);
  }
  public isStudent():boolean{
    let studId=sessionStorage.getItem('studId');
    let studPassword=sessionStorage.getItem('studPassword');
    console.log(studId+" "+studPassword);
    return !(studId==null);
  }
  public invokeLogout():void{
    sessionStorage.removeItem('studName');
    sessionStorage.removeItem('studPassword');
    sessionStorage.removeItem('adminName');
    sessionStorage.removeItem('adminPassword');
  }
  public extractUser(Id:String):Observable<any>{
    return this.http.get<any>(this.url+`getLogindetailsById/${Id}`)
  }
}

