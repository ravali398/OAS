export class ProjectURL {
    public static getUrl():string{
        return "http://localhost:8821/";
    }
}