import { Component, OnInit } from '@angular/core';
import { Application } from '../model/application';
import { ApplicationServiceService } from '../service/application-service.service';

@Component({
  selector: 'app-create-application',
  templateUrl: './create-application.component.html',
  styleUrls: ['./create-application.component.css']
})
export class CreateApplicationComponent implements OnInit {

  application:Application=new Application();
  msg="";
  constructor(private applicationservice:ApplicationServiceService) { }

  ngOnInit() {
  }
  public createApp():void{
    console.log(this.application);
    this.applicationservice.addApplication(this.application).subscribe((p)=>
    {
      this.msg=p;
      console.log(this.msg);
      alert("application has been added");
     
    }
  );
  

}
}

