import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { College } from '../model/college';
import { CollegeServiceService } from '../service/college-service.service';

@Component({
  selector: 'app-update-college',
  templateUrl: './update-college.component.html',
  styleUrls: ['./update-college.component.css']
})
export class UpdateCollegeComponent implements OnInit {

  college:College=new College();
  collegeId:number;
  bName:String;
    constructor(private r:ActivatedRoute,private cs:CollegeServiceService,private router:Router) { }
  
    ngOnInit() {
      this.collegeId=this.r.snapshot.params['p'];
      this.cs.extractById(this.collegeId).subscribe(response=>
       {
    this.college=response;
    this.bName=this.college.collegeName;
   
   })
    }
    public CollegeUpdation(){
      this.college.collegeName=this.bName;
    this.cs.updateById(this.college,this.college.collegeId).subscribe(response=>{
          console.log(response);
        alert("College is updated");
        this.router.navigate(['ViewCollege']);
      })
     
    
    }
  
  }
  
