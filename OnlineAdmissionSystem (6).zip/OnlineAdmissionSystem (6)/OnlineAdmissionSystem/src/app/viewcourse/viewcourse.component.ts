import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from '../model/course';
import { CourseServiceService } from '../service/course-service.service';

@Component({
  selector: 'app-viewcourse',
  templateUrl: './viewcourse.component.html',
  styleUrls: ['./viewcourse.component.css']
})
export class ViewcourseComponent implements OnInit {

  msg:String="";
courses:Course[]=[];
  constructor(private cs:CourseServiceService,private router:Router) { }

  ngOnInit() {
    this.cs.extractCourse().subscribe(response=>{ this.courses=response;})}


  

 

}
