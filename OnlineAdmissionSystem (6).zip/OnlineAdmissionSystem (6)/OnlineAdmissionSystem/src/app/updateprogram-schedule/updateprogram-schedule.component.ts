import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProgramScheduleId } from '../model/program-schedule-id';
import { ProgramscheduleIdService } from '../service/programschedule-id.service';

@Component({
  selector: 'app-updateprogram-schedule',
  templateUrl: './updateprogram-schedule.component.html',
  styleUrls: ['./updateprogram-schedule.component.css']
})
export class UpdateprogramScheduleComponent implements OnInit {

  programid:number;
  pstartDate:String;
  programschedule:ProgramScheduleId;
  constructor(private r:ActivatedRoute,private ps:ProgramscheduleIdService,private router:Router) { }

  ngOnInit() {
    this.programid=this.r.snapshot.params['p'];
    console.log(this.programid)
    this.ps.extractById(this.programid).subscribe(response=>{
      this.programschedule=response;
      this.pstartDate=this.programschedule.startDate.toDateString();
      console.log(this.pstartDate)

    })
}
 public updateSchedule(){
  //this.programschedule.startDate.toDateString()=this.pstartDate;
  this.ps.updateById(this.programschedule,this.programschedule.scheduleId).subscribe(response=>{
    console.log(response);
    alert("Schedule is updated");
    this.router.navigate(['viewBySchedule']);
  })
 
  }

}


