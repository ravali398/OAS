import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProgramScheduleId } from '../model/program-schedule-id';
import { ProgramscheduleIdService } from '../service/programschedule-id.service';

@Component({
  selector: 'app-getpsby-date',
  templateUrl: './getpsby-date.component.html',
  styleUrls: ['./getpsby-date.component.css']
})
export class GetpsbyDateComponent implements OnInit {

  StartDate:String;
  msg:String="";
  program:ProgramScheduleId[]=[];
  
    constructor(private bs:ProgramscheduleIdService,private router:Router) { 
      }
  
    
    ngOnInit() {
    }
    public ProgramScheduleByDate(){
      console.log(this.StartDate);
      this.bs.extractByDate(this.StartDate).subscribe(response=>{
        this.program=response;
        console.log(response);
          alert(this.StartDate);
        
      })
    }
}