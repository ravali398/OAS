import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetpsbyDateComponent } from './getpsby-date.component';

describe('GetpsbyDateComponent', () => {
  let component: GetpsbyDateComponent;
  let fixture: ComponentFixture<GetpsbyDateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetpsbyDateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetpsbyDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
