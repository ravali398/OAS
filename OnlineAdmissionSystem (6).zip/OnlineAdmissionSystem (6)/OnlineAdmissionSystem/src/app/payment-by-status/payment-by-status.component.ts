import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Payment } from '../model/payment';
import { PaymentServiceService } from '../service/payment-service.service';
@Component({
  selector: 'app-payment-by-status',
  templateUrl: './payment-by-status.component.html',
  styleUrls: ['./payment-by-status.component.css']
})
export class PaymentByStatusComponent implements OnInit {
  status:String;
  msg:String="";
  payment:Payment[]=[];
  constructor(private paymentService:PaymentServiceService,private router:Router) { 

  }

  ngOnInit() {
  }
  public PaymentByStatus(){
    console.log(this.status);
    this.paymentService.extractByStatus(this.status).subscribe(response=>{
      this.payment=response;
      if(this.status)
      console.log(response);
        alert(this.status);
      
    })
  }
}