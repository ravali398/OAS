import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from '../model/login';
import { LoginServiceService } from '../service/login-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

login:Login;
  loginId:string="";
 password:string="";
  msg:string="Welcome to Portal";
  errorMsg:string="Error in Login";
 invalidmsg:boolean=false;
 constructor(private router:Router,private loginService:LoginServiceService){

 }
  ngOnInit() {
    console.log("welcome");
  }

  public handleLogin():void{
  /*if(this.userName=="admin"&&this.userPassword=="cap@123")
  {
    console.log("welcome"+" "+this.userName);
    this.router.navigate(['welcome',this.userName]);
    this.invalidmsg=false;
  }
  else{
    this.invalidmsg=true;
  }
  }*/
  console.log(this.loginId);
  if(this.loginService.doLogin(this.loginId)){
    console.log("welcome"+" "+this.loginId);
    this.loginService.extractUser(this.loginId).subscribe((response)=>{
      this.login=response;})
      if(this.login.role=='admin' && this.login.password==this.password){
        this.router.navigate(['welcome',this.loginId]);
    this.invalidmsg=false;
      }else if(this.login.role=='student' && this.login.password==this.password){
        this.router.navigate(['welcomestudent',this.loginId]);
    this.invalidmsg=false;
      }
      
  
  else{
    this.invalidmsg=true;
  }
  }
}


}
