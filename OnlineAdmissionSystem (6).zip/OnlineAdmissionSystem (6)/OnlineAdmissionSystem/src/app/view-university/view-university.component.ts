import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { University } from '../model/university';
import { UniversityserviceService } from '../service/universityservice.service';

@Component({
  selector: 'app-view-university',
  templateUrl: './view-university.component.html',
  styleUrls: ['./view-university.component.css']
})
export class ViewUniversityComponent implements OnInit {

  msg:String="";
  university:University[]=[];
  universityId:number;
    constructor(private us:UniversityserviceService,private router:Router) { }
  
    ngOnInit() {
      this.us.extractUniversity().subscribe(response=>{ this.university=response;})}
  
     
  }
  
  