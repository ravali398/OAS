import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Login } from '../model/login';
import { User } from '../model/user';
import { UserServiceService } from '../service/user-service.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {
  loginId:String="";
  newpassword:String="";
  confirmpassword:String="";
  login:Login=new Login();
  constructor(private r:ActivatedRoute,private userService:UserServiceService,private router:Router) { }

  ngOnInit() {
    //this.loginId=this.r.snapshot.params['r'];
    
}
public resetPassword(){
  console.log(this.loginId+" "+this.newpassword);
  this.userService.extractLoginById(this.loginId).subscribe(response=>{
    this.login=response;
    this.newpassword=this.login.password;
   });
  this.login.loginId=this.loginId;
  this.login.password=this.newpassword;
  if(this.confirmpassword==this.newpassword){
  this.userService.resetLoginDetails(this.login,this.login.loginId).subscribe(response=>{
    console.log(response);
    alert("Password is reseted");
    this.router.navigate(['login']);
  })
  
 
  }else{
    alert("please check such that confirmpassword and new password must be same");
  }

}
}